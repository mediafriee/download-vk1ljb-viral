<html prefix="og: http://ogp.me/ns#" xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb" lang="en-gb" dir="ltr">
 <head> 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.css"> 
  <script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}
gtag('js',new Date());gtag('config','UA-158589140-1');</script> 
  <meta http-equiv="X-UA-Compatible" content="IE=edge"> 
  <meta name="viewport" content="width=device-width, initial-scale=1"> 
  <meta name="keywords" content="free fire, ff, info tourney free fire, tourney free fire, turnamen free fire, tournament free fire, info tourney ff, tourney ff, turnamen ff, tournament ff, turnamen free fire 2023, turnamen ff 2023, turnamen ff desember 2023, turnamen free fire desember 2023, turnamen free fire first warriors 2023"> 
  <meta name="author" content="Super User"> 
  <meta property="og:image" content="images/turnamen-ff-free-fire-desember-2023-first-warriors-2023-logo.jpg"> 
  <meta property="og:title" content="Turnamen Free Fire - FIRST WARRIORS 2023"> 
  <meta name="description" content="InfoTourney - Informasi Turnamen Free Fire Terlengkap dan Terpercaya | Turnamen Free Fire Untuk Level Amatir Hingga Professional"> 
  <meta name="generator" content="Joomla! - Open Source Content Management"> 
  <title>Turnamen Free Fire - GRATIS</title> 
  <link href="favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon"> 
  <link href="css/simple-line-icons.min.css" rel="stylesheet" type="text/css"> 
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous"> 
  <link rel="stylesheet" type="text/css" href="css/aa9e890be16ab1a3fb65a3ab9f71627f_0.css"> 
  <link href="//fonts.googleapis.com/css?family=Roboto:100,100italic,300,300italic,regular,italic,500,500italic,700,700italic,900,900italic&amp;subset=greek-ext" rel="stylesheet" type="text/css"> 
  <link rel="stylesheet" type="text/css" href="css/aa9e890be16ab1a3fb65a3ab9f71627f_1.css"> 
  <style type="text/css">body{font-family:Roboto,sans-serif;font-weight:300}h1{font-family:Roboto,sans-serif;font-weight:300}h2{font-family:Roboto,sans-serif;font-weight:300}h3{font-family:Roboto,sans-serif;font-weight:300}h4{font-family:Roboto,sans-serif;font-weight:300}h5{font-family:Roboto,sans-serif;font-weight:300}h6{font-family:Roboto,sans-serif;font-weight:300}.sticky-wrapper.is-sticky #sp-menu{top:0px;{.sticky-wrapper #sp-menu{top:30px;{.sp-megamenu-parent .sp-dropdown li.sp-menu-item>a{padding:5px!important}</style> 
 </head> 
 <body> 
  <div class="sp-megamenu-wrapper"> 
   <h2 id="utama" itemprop="name"> ISI FORMULIR PENDAFTARAN TURNAMEN</h2> 
   <h2 id="makas" style="display:none;" itemprop="name"> TERIMAKASIH SUDAH HADIR DI TURNAMEN INI<br><br>TEAM ANDA AKAN KAMI KONFIRMASI DALAM 24 JAM</h2> 
   <br> 
   <formulirnya> 
    <label style="font-weight: bold;" for="">Nama Team</label>    <input type="text" style="margin-top: 10px; font-size: 14px;width: 100%;
	height: auto;
	font-weight: bold;
	padding: 12px;
	color: #000;
	font-size: 14px;
	font-weight: 400;
	font-family: 'Lato',sans-serif;
	border: 1px solid #bdbebf;
	cursor: pointer;
	outline: none;" placeholder="Nama Team" class="product-form-input">
                            </div>
                            <formulirnya>
                            <div style="margin-top: 10px; font-size: 14px;">
                                <label style="font-weight: bold;" for="">Player 1</label>
                                <input type="text" style="margin-top: 10px; font-size: 14px;width: 100%;
	height: auto;
	font-weight: bold;
	padding: 12px;
	color: #000;
	font-size: 14px;
	font-weight: 400;
	font-family: 'Lato',sans-serif;
	border: 1px solid #bdbebf;
	cursor: pointer;
	outline: none;" placeholder="Nick Player 1" class="product-form-input">
                            </div>
                            <formulirnya>
                            <br>
                            <label style="font-weight: bold;" for="">Player 2</label>
                                <input type="text" style="margin-top: 10px; font-size: 14px;width: 100%;
	height: auto;
	font-weight: bold;
	padding: 12px;
	color: #000;
	font-size: 14px;
	font-weight: 400;
	font-family: 'Lato',sans-serif;
	border: 1px solid #bdbebf;
	cursor: pointer;
	outline: none;" placeholder="Nick Player 2" class="product-form-input">
                            <br>
                            <formulirnya>
                            <div style="margin-top: 10px; font-size: 14px;">
                                <label style="font-weight: bold;" for="">Player 3</label>
                                <input type="text" style="margin-top: 10px; font-size: 14px;width: 100%;
	height: auto;
	font-weight: bold;
	padding: 12px;
	color: #000;
	font-size: 14px;
	font-weight: 400;
	font-family: 'Lato',sans-serif;
	border: 1px solid #bdbebf;
	cursor: pointer;
	outline: none;" placeholder="Nick Player 3" class="product-form-input">
                            <br>
                            <formulirnya>
                            <label style="font-weight: bold;" for="">Player 4</label>
                                <input type="text" style="margin-top: 10px; font-size: 14px;width: 100%;
	height: auto;
	font-weight: bold;
	padding: 12px;
	color: #000;
	font-size: 14px;
	font-weight: 400;
	font-family: 'Lato',sans-serif;
	border: 1px solid #bdbebf;
	cursor: pointer;
	outline: none;" placeholder="Nick Player 4" class="product-form-input">
                            <br>
                            <formulirnya>
                            <div style="margin-top: 10px; font-size: 14px;">
                            <a onclick="donefor()" style="background: #ff0000;
    width: 100%;
    height: auto;
    margin-top: 10px;
    margin-left: auto;
    margin-right: auto;
    padding: 10px;
    color: #fff;
    font-size: 14px;
    font-family: Roboto;
    font-weight: bold;
    text-align: center;
    text-shadow: 1px 0px rgba(0, 0, 0, 0.3);
    border: 1px solid #ff0000;
    border-radius: 5px;
    box-shadow: 1px 1px 1px 1px rgba(0, 0, 0, 0.1);
    outline: none;
    display: block;">Kirim</a>
                            </div>
                            </formulirnya>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
function donefor() {
                $('#makas').fadeIn();
                $('formulirnya').hide();
                $('#utama').hide();
            }
</script>
                            </div></body></html>